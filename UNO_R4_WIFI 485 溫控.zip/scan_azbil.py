import serial
import time

def calculate_crc(data):
    crc = 0xFFFF
    for pos in data:
        crc ^= pos
        for _ in range(8):
            if (crc & 1) != 0:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return crc.to_bytes(2, byteorder='little')

# 序列埠基本設定
PORT = 'COM8'
ser = serial.Serial(PORT, 9600, parity='O', timeout=0.05)

# 暴力掃描 Azbil 四大核心區間段（完全涵蓋手冊 5000 區、EEPROM 區與暫存器基底）
scan_blocks = [
#    range(0, 300),         # 基礎數據與狀態區 (0H - 12CH)
#    range(5000, 5300),     # RAM 核心區（包含手冊截圖的 5205 等所有周邊）
#    range(18432, 18500),   # 經典 4800H 區（高階型號動態區）
#    range(21500, 21700),    # EEPROM 備份儲存區（斷電不丟失區）
   range(9000,10000)
]

print(f"正在透過 {PORT} 進行大範圍地毯式暴力掃描...")
print("提示：如果面板溫度目前是 25 度，我們正在尋找讀值為 250、25 或 2500 的暫存器...\n")

total_found = 0
for block in scan_blocks:
    for addr in block:
        addr_bytes = addr.to_bytes(2, byteorder='big')
        cmd = b'\x01\x03' + addr_bytes + b'\x00\x01'
        cmd += calculate_crc(cmd)
        
        ser.write(cmd)
        time.sleep(0.015)  # 壓縮延遲時間，進行高速連發掃描
        res = ser.read(10)
        
        # 判斷是否為標準的成功回應 (01 03 02 ...)
        if len(res) >= 5 and res[0] == 0x01 and res[1] == 0x03 and res[2] == 0x02:
            val = int.from_bytes(res[3:5], byteorder='big', signed=True)
            
            # 只要不是 0，就把地址與數值通通逼供出來
            if val != 0:
                print(f"🌟 撈到有效暫存器！ 十進位位址: {addr:5d} (十六進位: {hex(addr)}) -> 當前數值: {val:5d}")
                total_found += 1

ser.close()
print(f"\n掃描結束。共找到 {total_found} 個帶有數值的有效暫存器。")
