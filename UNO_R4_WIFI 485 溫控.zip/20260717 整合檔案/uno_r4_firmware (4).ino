/*
  uno_r4_firmware.ino  (LM35類比溫度感測器版本)
  --------------------
  Arduino UNO R4 WiFi 作為獨立的溫度監控閘道器：
    LM35 溫度感測器 --類比訊號(ADC)--> UNO R4 WiFi
    UNO R4 WiFi 內建 WiFi --MQTT(TLS)--> HiveMQ Cloud

  【跟原本Modbus/RS485版本的差異】
    原本這台裝置是透過RS485讀取Azbil C15TV0TA030A溫控器(Modbus RTU)。
    現在改成直接用 LM35 類比溫度感測器，不需要RS485模組、不需要Modbus函式庫，
    只需要一隻類比輸入腳位讀電壓、換算成溫度即可，接線和程式都簡單很多。

  LM35 感測器原理：
    LM35 是類比輸出的溫度IC，輸出電壓與溫度成正比，比例是 10mV / °C，
    例如輸出電壓 250mV，代表溫度是 25.0°C；輸出電壓 0mV，代表溫度是 0°C。
    (注意：一般常見的LM35只能量測「正溫度」，若環境溫度可能低於0°C，
     需要額外的負電壓電路，本韌體以正溫度環境為前提，不另外處理負電壓)

  接線 (LM35 <-> UNO R4 WiFi)：
    LM35 平面朝自己看，由左到右依序是：Vs / Vout / GND
      LM35 Vs(左腳)   -> UNO R4 的 5V
      LM35 Vout(中腳) -> UNO R4 的 A0 (可在下面 LM35_PIN 改成其他類比腳位)
      LM35 GND(右腳)  -> UNO R4 的 GND
    建議在 Vout 與 GND 之間並接一顆 0.1uF 陶瓷電容，可以濾掉一些高頻雜訊，
    讀值會更穩定(非必要，但實測有雜訊問題時很有效)。

  ⚠️ 重要提醒：
    - LM35 的Vs建議接5V(UNO R4的5V腳位，不是3.3V)，這樣量測範圍才夠大(最高可到約150°C)。
    - 類比訊號很容易受電源雜訊、線材長度影響，如果讀值一直跳動不穩，
      可以先檢查:(1)接線是否夠短、(2)是否有加濾波電容、(3)LM35腳位有沒有接錯。
    - 韌體內建「多次取樣平均」(見 ADC_SAMPLE_COUNT設定)，可有效降低單次讀取雜訊造成的異常尖峰。

  需要安裝的 PlatformIO 函式庫 (寫在 platformio.ini 的 lib_deps)：
    - arduino-libraries/ArduinoMqttClient
    - arduino-libraries/Arduino_JSON
    - WiFiS3                     (UNO R4 WiFi 內建，開發板套件自帶，會自動抓到)
    (原本的 ModbusMaster 已不再需要，可以從 lib_deps 移除)

  燒錄前務必修改下方「使用者設定」區塊。

  【與模造區PC端的整合說明】
    這台裝置負責「洗淨區」。工廠另一台PC(模造區，直接用RS485接電腦讀取)會執行
    gui_monitor.py，兩邊各自獨立讀取溫度，再各自發布到不同的MQTT topic：
      - 模造區(PC端) -> azbil/c15/temperature/molding
      - 洗淨區(本裝置) -> azbil/c15/temperature/washing
    gui_monitor.py 會同時顯示兩個職場的溫度(模造區本機讀取 + 洗淨區訂閱MQTT收值)，
    雲端Dashboard(放在GitHub Pages)也會訂閱這兩個topic，手機打開網頁即可同時看到兩區溫度。
    (topic不變，所以gui_monitor.py跟雲端Dashboard完全不用改，這邊換感測器不影響它們)
*/

// ================== 函式庫引入 ==================
#include <WiFiS3.h>          // UNO R4 WiFi 專用的 WiFi 函式庫，負責連上無線網路
#include <WiFiSSLClient.h>   // 提供 TLS/SSL 加密連線功能，用來跟 MQTT Broker 做加密通訊
#include <ArduinoMqttClient.h> // MQTT 通訊協定客戶端，負責連線/發布/訂閱 MQTT 訊息
#include <Arduino_JSON.h>    // 用來組出 JSON 格式字串，方便把資料包成標準格式送出

// ================== 使用者設定 ==================
// --- WiFi 連線資訊 ---
const char* WIFI_SSID = "vivo 2006";     // 你的 WiFi 名稱(SSID)
const char* WIFI_PASSWORD = "0919120001";  // 你的 WiFi 密碼

// --- HiveMQ Cloud (MQTT over TLS) 連線資訊 ---
const char* MQTT_HOST = "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud"; // MQTT Broker 主機位址(HiveMQ Cloud 提供)
const int   MQTT_PORT = 8883;                  // MQTT over TLS 的標準連接埠(加密連線用 8883，非加密才是 1883)
const char* MQTT_USERNAME = "temp";            // 登入 MQTT Broker 用的帳號
const char* MQTT_PASSWORD = "temp0001";        // 登入 MQTT Broker 用的密碼
// 注意：這台裝置負責「洗淨區」。PC端(gui_monitor.py)的「模造區」讀值會發布到另一個獨立的topic
// (azbil/c15/temperature/molding)，兩邊topic不同才不會互相蓋掉彼此的資料，PC端GUI跟雲端Dashboard
// 都是靠topic路徑分辨這筆溫度資料是哪個職場的。
const char* MQTT_TOPIC = "azbil/c15/temperature/washing"; // 發布溫度資料時要送去的「主題(topic)」路徑，訂閱端要訂閱同一個主題才收得到
const char* MQTT_CLIENT_ID = "uno-r4-wifi-gateway"; // 這台裝置在 MQTT Broker 上的識別名稱，同一個 Broker 下不可與其他裝置重複

// --- LM35 類比溫度感測器設定 ---
const int LM35_PIN = A0;              // LM35 Vout 接的類比輸入腳位
const float ADC_REF_MV = 5000.0;      // ADC參考電壓(單位mV)。LM35的Vs接5V時，這裡要設5000
const int ADC_RESOLUTION_BITS = 14;   // UNO R4 支援到14位元解析度(比一般Arduino的10位元更精細)，數值越大讀值越細膩
const int ADC_SAMPLE_COUNT = 20;      // 每次讀取時，連續取樣這麼多次再平均，可有效濾掉雜訊造成的異常尖峰
const float TEMP_OFFSET_C = 0.0;      // 校正用的溫度補償值(°C)。若跟你手邊的溫度計比對後發現系統性偏差，可在這裡加減微調

const unsigned long POLL_INTERVAL_MS = 1000; // 每隔多少毫秒讀取一次溫度並發布，1000毫秒(1秒)讀一次，配合網頁端趨勢圖需求
// ==================================================

// ================== 全域物件與變數 ==================
WiFiSSLClient wifiClient;          // 建立一個支援 TLS 加密的網路連線物件，之後給 MQTT 用來連線 Broker
MqttClient mqttClient(wifiClient); // 建立 MQTT 客戶端物件，底層透過上面的 wifiClient 做加密連線
unsigned long lastPoll = 0;        // 記錄「上一次讀取溫度」的時間點(millis())，用來計算是否已經到了下一次讀取的時間
long adcMaxValue = 1023;           // ADC最大讀值(依ADC_RESOLUTION_BITS計算，setup()時會重新賦值)

// ================== WiFi 連線函式 ==================
void connectWiFi() {
  Serial.print("連線 WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD); // 開始嘗試連線指定的 WiFi 熱點
  while (WiFi.status() != WL_CONNECTED) { // 持續檢查連線狀態，還沒連上就一直等待
    delay(500);       // 每0.5秒檢查一次，避免無意義地瘋狂查詢
    Serial.print(".");// 印出點點點，讓使用者知道程式還在嘗試連線(不是當機)
  }
  // 連線成功後，印出目前板子分配到的區網 IP 位址，方便除錯確認
  Serial.println("\nWiFi 已連線，IP: " + WiFi.localIP().toString());
}

// ================== MQTT 連線函式 ==================
void connectMqtt() {
  mqttClient.setId(MQTT_CLIENT_ID); // 設定這台裝置在 MQTT Broker 上的識別 ID
  mqttClient.setUsernamePassword(MQTT_USERNAME, MQTT_PASSWORD); // 設定登入帳密(HiveMQ Cloud 需要帳密驗證)

  Serial.print("連線 MQTT Broker: ");
  Serial.println(MQTT_HOST);

  // 嘗試連線，若失敗會回傳 false，進入迴圈持續重試
  while (!mqttClient.connect(MQTT_HOST, MQTT_PORT)) {
    Serial.print("MQTT 連線失敗, 錯誤碼 = ");
    Serial.println(mqttClient.connectError()); // 印出錯誤代碼，方便查閱函式庫文件排查問題(例如帳密錯誤、憑證問題等)
    delay(2000); // 等待2秒後再重試，避免短時間內狂送連線請求
  }
  Serial.println("MQTT 已連線");
}

// ================== 初始化設定(開機時執行一次) ==================
void setup() {
  Serial.begin(115200);              // 開啟序列埠監控，鮑率設定為115200，方便透過 Serial Monitor 看除錯訊息
  while (!Serial && millis() < 3000) {} // 等待序列埠準備好，最多等3秒(避免板子卡在這裡等不到就一直卡住)

  connectWiFi();  // 先確保 WiFi 連上
  connectMqtt();  // 再確保 MQTT 連上

  // 設定ADC解析度：UNO R4支援到14位元(數值範圍0~16383)，預設是10位元(0~1023)，
  // 提高解析度可以讓LM35這種變化幅度較小的類比訊號讀值更精細、更平滑。
  analogReadResolution(ADC_RESOLUTION_BITS);
  adcMaxValue = (1L << ADC_RESOLUTION_BITS) - 1; // 例如14位元 -> 2^14 - 1 = 16383
}

// ================== 讀取溫度函式 ==================
// 從LM35讀取一筆溫度資料：連續取樣ADC_SAMPLE_COUNT次取平均，換算成攝氏溫度後寫入outTemp
bool readTemperature(float &outTemp) {
  long sum = 0;
  for (int i = 0; i < ADC_SAMPLE_COUNT; i++) {
    sum += analogRead(LM35_PIN);
    delay(2); // 每次取樣間隔一點點時間，讓ADC有時間穩定，也能取樣到不同時間點的雜訊，平均後效果更好
  }
  float avgRaw = (float)sum / ADC_SAMPLE_COUNT;

  // ADC讀值換算成實際電壓(mV)：讀值 / ADC最大值 * 參考電壓
  float voltageMv = (avgRaw / (float)adcMaxValue) * ADC_REF_MV;

  // LM35: 10mV代表1°C，所以電壓(mV)除以10就是攝氏溫度，再加上校正補償值
  outTemp = (voltageMv / 10.0) + TEMP_OFFSET_C;
  return true; // LM35是類比讀取，沒有「通訊失敗」的狀況，這裡固定回傳true(保留回傳值是為了跟原本呼叫端寫法相容)
}

// ================== 發布溫度到 MQTT 函式 ==================
void publishTemperature(float temp) {
  JSONVar payload; // 建立一個 JSON 物件，用來組裝要送出的資料內容
  payload["device"] = "lm35";                       // 標示資料來源裝置型號，方便訂閱端分辨資料是哪台儀器送來的
  payload["area"] = "washing";                     // 標示這是哪個職場的資料("washing"=洗淨區)，PC端GUI跟雲端Dashboard都靠這個欄位分類
  payload["temperature_c"] = temp;                 // 這次讀到的攝氏溫度數值
  payload["timestamp"] = (long)(millis() / 1000);  // 時間戳記：用開機後經過的秒數表示(注意：這不是真實世界時間，只是相對開機時間)

  String json = JSON.stringify(payload); // 把 JSON 物件轉換成字串格式，才能透過 MQTT 傳送出去

  // 開始一則 MQTT 訊息：
  //   第2個參數 json.length()：訊息的位元組長度
  //   第3個參數 true：retain旗標，代表 Broker 會保留這則訊息，新訂閱者一連上就能立刻拿到「最後一次」的溫度值
  //   第4個參數 1：QoS等級1，代表訊息至少會送達一次(可能重複，但不會遺失)
  mqttClient.beginMessage(MQTT_TOPIC, json.length(), true /*retain*/, 1 /*qos*/);
  mqttClient.print(json);   // 寫入實際的 JSON 內容
  mqttClient.endMessage();  // 結束並真正送出這則訊息

  Serial.println("已發布: " + json); // 在序列埠印出這次送出的內容，方便對照雲端是否有正確收到
}

// ================== 主迴圈(開機後不斷重複執行) ==================
void loop() {
  // 隨時檢查 WiFi 是否斷線，若斷線就自動重新連線，確保裝置長時間運作的穩定性(避免路由器重開機等意外導致永久斷線)
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }
  // 同樣地，檢查 MQTT 連線是否還在，斷線就自動重連
  if (!mqttClient.connected()) {
    connectMqtt();
  }
  mqttClient.poll(); // 讓 MQTT 客戶端處理背景事務(例如維持連線的心跳訊號)，這行必須經常呼叫，否則連線可能會被 Broker 判定逾時斷開

  // 計算距離上次讀取溫度是否已經過了設定的間隔時間(POLL_INTERVAL_MS)
  if (millis() - lastPoll >= POLL_INTERVAL_MS) {
    lastPoll = millis(); // 更新「上次讀取時間」為現在，重新開始倒數下一次的間隔
    float temp;
    if (readTemperature(temp)) { // 讀取成功才繼續往下印出並發布，讀取失敗則這次迴圈就跳過，等下一次再試
      Serial.print("PV = ");
      Serial.print(temp, 2); // 印出溫度，保留小數點後2位方便閱讀
      Serial.println(" °C");
      publishTemperature(temp); // 把這次讀到的溫度發布到 MQTT
    }
  }
}
