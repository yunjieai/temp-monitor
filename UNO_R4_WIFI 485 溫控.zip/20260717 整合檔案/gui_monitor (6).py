"""
gui_monitor.py
----------------
桌面GUI（雙職場整合版）：
  - 模造區：PC本機透過RS485直接讀取 Azbil C15TV0TA030A 溫控器
  - 洗淨區：UNO R4 WiFi 從站讀取自己那邊的溫控器，透過MQTT(HiveMQ Cloud)回報給本程式

本程式同時顯示「兩個職場」的溫度，各自獨立記錄/統計/畫圖，並各自發布到獨立的MQTT topic，
讓放在GitHub Pages的雲端Dashboard(cloud_dashboard/index.html)也能同時訂閱兩邊的資料，
手機打開網頁就能同時看到兩個職場的溫度。

MQTT topic配置（兩職場各自獨立，才不會互相覆蓋）：
  - 模造區(本程式本機讀值後發布) -> azbil/c15/temperature/molding
  - 洗淨區(UNO R4發布，本程式訂閱接收)  -> azbil/c15/temperature/washing

功能總覽（每個職場都各自有一份）：
  1. 即時溫度      - 畫面上方快速總覽兩職場目前溫度
  2. 每秒          - 最近 SEC_HISTORY_LEN 筆原始讀值（即時監看用）
  3. 每分(統計)    - 每跨過一分鐘，把上一分鐘所有秒級讀值計算 平均/最大/最小/標準差
  4. 每時(統計)    - 每跨過一小時，把上一小時所有秒級讀值計算 平均/最大/最小/標準差
  5. CSV落地儲存   - 每秒原始值、每分統計、每時統計，分別依「職場+日期」存成CSV，程式重開資料不遺失
  6. 今日熱力圖    - X軸=10分鐘區塊(00~50)，Y軸=0~23時，用顏色呈現當天各時段溫度高低

安裝套件（若尚未安裝）：
  pip install pymodbus pyserial paho-mqtt matplotlib numpy

執行：
  python gui_monitor.py
"""

import sys
import time
import json
import ssl
import csv
import os
import queue
import statistics
import smtplib
import datetime
import subprocess
import tempfile
from xml.sax.saxutils import escape as xml_escape
from collections import deque
from email.mime.text import MIMEText
import urllib.request
import urllib.parse
import tkinter as tk
from tkinter import ttk
import serial.tools.list_ports
from pymodbus.client import ModbusSerialClient
import paho.mqtt.client as mqtt
import numpy as np

import matplotlib
matplotlib.use("TkAgg")
# 讓圖表能正常顯示中文標題（Windows內建字型，找不到會自動退回系統預設）
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "SimHei", "Arial Unicode MS"]
matplotlib.rcParams["axes.unicode_minus"] = False
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# 僅供Telegram的HTTPS請求使用truststore(Windows系統信任的憑證清單)，
# 刻意不呼叫truststore.inject_into_ssl()做全域替換，避免影響到MQTT(paho-mqtt)原本正常運作的TLS驗證機制。
try:
    import truststore
    _TELEGRAM_SSL_CONTEXT = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
except ImportError:
    print("提醒：尚未安裝 truststore，若Telegram發送出現SSL憑證錯誤，"
          "請執行: python -m pip install truststore")
    _TELEGRAM_SSL_CONTEXT = ssl.create_default_context()

# ====== Modbus設定：模造區(本機直接用RS485讀取) ======
DEFAULT_SERIAL_PORT = "COM8"
BAUDRATE = 9600
PARITY = "O"          # 依C68實測值＝奇同位
SLAVE_ID = 1
PV_REGISTER = 0x238D      # 官方通訊資料清單確認的PV位址（十進位9101 / 0x238D）
DECIMALS = 0              # 實測確認：PV原始值無小數點，DECIMALS=0(raw值除以10^0=1)
POLL_INTERVAL_MS = 1000   # 每1秒讀取/檢查一次
# ==========================================================================

# ====== 圖表設定 ======
SEC_HISTORY_LEN = 60      # 每秒圖：保留最近60筆讀值（約最近1分鐘）
MIN_HISTORY_LEN = 60      # 每分(統計)圖：保留最近60筆分鐘統計（約最近1小時）
HOUR_HISTORY_LEN = 24     # 每時(統計)圖：保留最近24筆小時統計（最近1天）
# ==========================================================================

# ====== CSV落地儲存設定 ======
# 若被PyInstaller打包成exe執行(sys.frozen為True)，__file__會指向暫存解壓縮路徑，
# 因此改用 sys.executable(exe檔本身的路徑)所在的資料夾，確保CSV固定存在exe旁邊，
# 不會因為程式關閉、暫存資料夾被清空而遺失資料。
if getattr(sys, "frozen", False):
    _BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    _BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(_BASE_DIR, "temp_logs")
os.makedirs(DATA_DIR, exist_ok=True)
# ==========================================================================

# ====== MQTT設定：填入你的HiveMQ Cloud資訊，並把ENABLE_MQTT設為True才會啟用 ======
# 這組帳密是「裝置端」用的，需要可讀寫(發布molding + 訂閱washing)的權限，
# 只會存在你自己的電腦上執行，不會被放到公開的GitHub repo，所以維持原本帳密即可。
# (雲端Dashboard網頁那邊，因為原始碼是公開的，請改用另一組「唯讀/僅可訂閱」的帳密，
#  詳見 cloud_dashboard/README.md)
ENABLE_MQTT = True
MQTT_HOST = "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USERNAME = "temp"
MQTT_PASSWORD = "temp0001"
MQTT_CLIENT_ID = "gui-monitor-publisher"
MQTT_PUBLISH_INTERVAL_SEC = 2   # 為避免太頻繁發送，模造區每隔幾秒才發布一次(畫面仍每1秒更新)

# 兩職場各自獨立的MQTT topic：molding是本程式自己發布，washing是訂閱UNO R4發布的資料
MQTT_TOPIC_MOLDING = "azbil/c15/temperature/molding"
MQTT_TOPIC_WASHING = "azbil/c15/temperature/washing"
# ==========================================================================

# ====== Telegram推播設定（公司網路已封鎖telegram.org，先關閉避免持續報錯）======
ENABLE_TELEGRAM = False
TELEGRAM_BOT_TOKEN = "8339192759:AAE4vXsQZ3GcuzA_sRu3XiAuzfeMde6dQ24"
TELEGRAM_CHAT_ID = "8987703678"
# ==========================================================================

# ====== Email警報設定：超過上限溫度時透過公司Exchange信箱寄信通知 ======
ENABLE_EMAIL = True
SMTP_HOST = "smtp.office365.com"      # !! 請跟公司IT確認實際SMTP伺服器位址 !!
SMTP_PORT = 587                          # 587=STARTTLS加密(較常見)；若IT說用25且不加密則改成25
SMTP_USE_TLS = True                      # 若公司內網SMTP不需要加密，改成False
SMTP_REQUIRE_AUTH = True                 # 若公司內網SMTP不需要帳密驗證(常見於印表機/系統用途)，改成False
SMTP_USERNAME = "you@yourcompany.com"    # 寄件人信箱(登入帳號，通常跟寄件人相同)
SMTP_PASSWORD = "your_email_password"    # 信箱密碼(若公司用Microsoft 365且開啟雙重驗證，需改用「應用程式密碼」)
EMAIL_FROM = "you@yourcompany.com"       # 寄件人
EMAIL_TO = "you@yourcompany.com"         # 收件人(通常填自己的信箱，手機Email App會跳通知)

TEMP_HIGH_THRESHOLD = 30.0    # 超過這個溫度(°C)才發送警報
ALERT_HYSTERESIS = 1.0          # 溫度要降回「門檻-1.0°C」以下才會重置警報狀態，避免在門檻附近來回通知(防手震)
# ==========================================================================

# ====== 職場設定：新增/移除職場時，主要只需要調整這裡 ======
WORKPLACES = [
    {"key": "molding", "label": "模造區", "source": "modbus", "mqtt_topic": MQTT_TOPIC_MOLDING},
    {"key": "washing", "label": "洗淨區", "source": "mqtt", "mqtt_topic": MQTT_TOPIC_WASHING},
]
# ==========================================================================

# ====== WiFi連線設定 ======
# 讓使用者可以在畫面上輸入SSID/密碼，連到自己的WiFi裝置(例如手機熱點/隨身路由器)，
# 不需要知道電腦目前連接的公司WiFi密碼。
# 原理：動態產生一份Windows WLAN設定檔(XML)，透過 netsh wlan add profile 匯入，
# 再用 netsh wlan connect 連線。
# 注意：新增WLAN設定檔通常需要「系統管理員權限」，若連線失敗且錯誤訊息提到權限不足，
# 請以滑鼠右鍵「以系統管理員身分執行」重新開啟本程式(或exe)。
# 此樣板假設路由器為WPA2-Personal(AES)加密，是目前最常見的家用/手機熱點加密方式；
# 若你的WiFi裝置使用WPA3或其他加密方式，可能需要調整此樣板。
WIFI_PROFILE_TEMPLATE = """<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <n>{ssid}</n>
    <SSIDConfig>
        <SSID>
            <n>{ssid}</n>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>manual</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>{password}</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>
"""
# ==========================================================================


def send_telegram_message(text: str) -> bool:
    """透過Telegram Bot API發送一則文字訊息，成功回傳True，失敗回傳False（不會拋出例外中斷主程式）"""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": TELEGRAM_CHAT_ID, "text": text}).encode("utf-8")
    try:
        handler = urllib.request.HTTPSHandler(context=_TELEGRAM_SSL_CONTEXT)
        opener = urllib.request.build_opener(handler)
        req = urllib.request.Request(url, data=data)
        with opener.open(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"Telegram發送失敗: {e}")
        return False


def send_email_alert(subject: str, body: str) -> bool:
    """透過公司Exchange SMTP寄出警報信件，成功回傳True，失敗回傳False（不會拋出例外中斷主程式）"""
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = EMAIL_TO

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as server:
            if SMTP_USE_TLS:
                server.starttls()
            if SMTP_REQUIRE_AUTH:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, [EMAIL_TO], msg.as_string())
        return True
    except Exception as e:
        print(f"Email發送失敗: {e}")
        return False


# ---------------------------------------------------------------------
# 統計小工具
# ---------------------------------------------------------------------
def _compute_stats(values) -> dict:
    """計算一組讀值的 平均/最大/最小/標準差(母體標準差)/樣本數"""
    return {
        "mean": statistics.mean(values),
        "max": max(values),
        "min": min(values),
        "std": statistics.pstdev(values),
        "count": len(values),
    }


def _append_csv_row(path: str, header, row):
    """把一列資料附加寫入CSV，檔案不存在時自動先寫入表頭。使用utf-8-sig讓Excel開啟中文表頭不亂碼。"""
    is_new = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if is_new:
            writer.writerow(header)
        writer.writerow(row)


def _autoscale(ax, x, y_low, y_high):
    """依目前資料自動調整座標軸範圍，避免曲線/陰影帶貼邊或看不出變化。"""
    if not x:
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        return
    ax.set_xlim(1, max(x[-1], 2))
    ymin, ymax = min(y_low), max(y_high)
    if ymin == ymax:
        ymin -= 1
        ymax += 1
    pad = (ymax - ymin) * 0.15 or 1
    ax.set_ylim(ymin - pad, ymax + pad)


# ---------------------------------------------------------------------
# WorkplaceRecorder：純資料邏輯(不含任何tkinter/matplotlib)，
# 負責一個職場的 秒/分/時 歷史緩衝區、統計計算、CSV落地儲存。
# 模造區、洗淨區各自各建立一份，彼此完全獨立。
# ---------------------------------------------------------------------
class WorkplaceRecorder:
    def __init__(self, key: str, label: str, data_dir: str):
        self.key = key
        self.label = label
        self.data_dir = data_dir

        self.sec_history = deque(maxlen=SEC_HISTORY_LEN)
        self.min_history = deque(maxlen=MIN_HISTORY_LEN)
        self.hour_history = deque(maxlen=HOUR_HISTORY_LEN)
        self.today_minute_stats = []

        self._minute_buffer = []
        self._current_minute_key = None
        self._hour_buffer = []
        self._current_hour_key = None
        self.today_date = datetime.date.today()

        self.latest_temp = None
        self.latest_update_time = None   # datetime.datetime，最近一次成功收到溫度的時間(用來判斷離線)

    # -- CSV路徑(依「職場key + 日期」分開存檔，兩職場資料不會混在一起) --
    def _raw_csv_path(self, d: datetime.date) -> str:
        return os.path.join(self.data_dir, f"raw_{self.key}_{d.strftime('%Y%m%d')}.csv")

    def _minute_csv_path(self, d: datetime.date) -> str:
        return os.path.join(self.data_dir, f"minute_stats_{self.key}_{d.strftime('%Y%m%d')}.csv")

    def _hour_csv_path(self, d: datetime.date) -> str:
        return os.path.join(self.data_dir, f"hour_stats_{self.key}_{d.strftime('%Y%m%d')}.csv")

    def load_today_data(self):
        """啟動時把「今天」已經存在的CSV資料讀回來，讓趨勢圖/熱力圖不會因重開程式而歸零"""
        minute_path = self._minute_csv_path(self.today_date)
        if os.path.exists(minute_path):
            try:
                with open(minute_path, newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        stats = {
                            "timestamp": row["分鐘(YYYYMMDDHHMM)"],
                            "mean": float(row["平均"]),
                            "max": float(row["最大"]),
                            "min": float(row["最小"]),
                            "std": float(row["標準差"]),
                            "count": int(row["樣本數"]),
                        }
                        self.min_history.append(stats)
                        self.today_minute_stats.append(stats)
            except Exception as e:
                print(f"[{self.label}] 讀取今日分鐘統計CSV失敗，將略過: {e}")

        hour_path = self._hour_csv_path(self.today_date)
        if os.path.exists(hour_path):
            try:
                with open(hour_path, newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        stats = {
                            "timestamp": row["小時(YYYYMMDDHH)"],
                            "mean": float(row["平均"]),
                            "max": float(row["最大"]),
                            "min": float(row["最小"]),
                            "std": float(row["標準差"]),
                            "count": int(row["樣本數"]),
                        }
                        self.hour_history.append(stats)
            except Exception as e:
                print(f"[{self.label}] 讀取今日小時統計CSV失敗，將略過: {e}")

    def _start_new_day(self, new_date: datetime.date):
        """跨日時重置「今日」用的熱力圖資料（趨勢圖的捲動視窗維持連續，不重置）"""
        self.today_date = new_date
        self.today_minute_stats = []

    def record(self, temp: float, now: datetime.datetime = None):
        """記錄一筆新讀值：更新秒級歷史、寫CSV、偵測分鐘/小時邊界並計算統計"""
        if now is None:
            now = datetime.datetime.now()

        if now.date() != self.today_date:
            self._start_new_day(now.date())

        self.latest_temp = temp
        self.latest_update_time = now

        # ---- 每秒 ----
        self.sec_history.append(temp)
        _append_csv_row(
            self._raw_csv_path(self.today_date),
            ["時間戳", "溫度(°C)"],
            [now.strftime("%Y-%m-%d %H:%M:%S"), f"{temp:.1f}"],
        )

        # ---- 每分(統計)：偵測「分鐘」是否已經跳到下一分鐘 ----
        minute_key = now.strftime("%Y%m%d%H%M")
        if self._current_minute_key is None:
            self._current_minute_key = minute_key
        if minute_key != self._current_minute_key:
            if self._minute_buffer:
                stats = _compute_stats(self._minute_buffer)
                stats["timestamp"] = self._current_minute_key
                self.min_history.append(stats)
                self.today_minute_stats.append(stats)
                _append_csv_row(
                    self._minute_csv_path(self.today_date),
                    ["分鐘(YYYYMMDDHHMM)", "平均", "最大", "最小", "標準差", "樣本數"],
                    [stats["timestamp"], f"{stats['mean']:.2f}", f"{stats['max']:.1f}",
                     f"{stats['min']:.1f}", f"{stats['std']:.2f}", stats["count"]],
                )
            self._minute_buffer = []
            self._current_minute_key = minute_key
        self._minute_buffer.append(temp)

        # ---- 每時(統計)：偵測「小時」是否已經跳到下一小時 ----
        hour_key = now.strftime("%Y%m%d%H")
        if self._current_hour_key is None:
            self._current_hour_key = hour_key
        if hour_key != self._current_hour_key:
            if self._hour_buffer:
                hstats = _compute_stats(self._hour_buffer)
                hstats["timestamp"] = self._current_hour_key
                self.hour_history.append(hstats)
                _append_csv_row(
                    self._hour_csv_path(self.today_date),
                    ["小時(YYYYMMDDHH)", "平均", "最大", "最小", "標準差", "樣本數"],
                    [hstats["timestamp"], f"{hstats['mean']:.2f}", f"{hstats['max']:.1f}",
                     f"{hstats['min']:.1f}", f"{hstats['std']:.2f}", hstats["count"]],
                )
            self._hour_buffer = []
            self._current_hour_key = hour_key
        self._hour_buffer.append(temp)

    def is_online(self, stale_after_sec: float) -> bool:
        """最近一筆資料若在 stale_after_sec 秒內收到，視為「線上」"""
        if self.latest_update_time is None:
            return False
        return (datetime.datetime.now() - self.latest_update_time).total_seconds() <= stale_after_sec


# ---------------------------------------------------------------------
# WorkplaceChartPanel：單一職場的圖表區塊(每秒/每分/每時/今日熱力圖)，
# 綁定一份 WorkplaceRecorder，畫面內容從recorder讀取，本身不做任何資料計算。
# ---------------------------------------------------------------------
class WorkplaceChartPanel(tk.Frame):
    def __init__(self, parent, recorder: WorkplaceRecorder, **kwargs):
        super().__init__(parent, bg="white", **kwargs)
        self.recorder = recorder

        header = tk.Frame(self, bg="white")
        header.pack(side="top", fill="x", padx=6, pady=(6, 0))
        self.count_label = tk.Label(header, text="今日已收集：0 分鐘 / 0 小時",
                                     font=("Microsoft JhengHei", 9), bg="white", fg="gray")
        self.count_label.pack(side="left")

        chart_holder = tk.Frame(self, bg="white", highlightbackground="black", highlightthickness=1)
        chart_holder.pack(side="top", fill="both", expand=True, padx=6, pady=6)

        self.fig = Figure(figsize=(10.6, 4.6), dpi=100)
        gs = self.fig.add_gridspec(2, 2, hspace=0.55, wspace=0.3)
        self.ax_sec = self.fig.add_subplot(gs[0, 0])
        self.ax_min = self.fig.add_subplot(gs[0, 1])
        self.ax_hour = self.fig.add_subplot(gs[1, 0])
        self.ax_heat = self.fig.add_subplot(gs[1, 1])

        self.ax_sec.set_title("每秒", fontsize=11, fontweight="bold")
        self.ax_min.set_title("每分(平均/最大/最小)", fontsize=11, fontweight="bold")
        self.ax_hour.set_title("每時(平均/最大/最小)", fontsize=11, fontweight="bold")
        for ax in (self.ax_sec, self.ax_min, self.ax_hour):
            ax.grid(True, linewidth=0.5, alpha=0.6)
            ax.tick_params(labelsize=7)

        (self.line_sec,) = self.ax_sec.plot([], [], color="#4a7ebb", linewidth=1.2)
        (self.line_min,) = self.ax_min.plot([], [], color="#c0504d", linewidth=1.2, label="平均")
        (self.line_hour,) = self.ax_hour.plot([], [], color="#8ab53f", linewidth=1.2, label="平均")
        self.band_min = None   # 每分圖的 最大~最小 陰影區間（動態建立/移除）
        self.band_hour = None  # 每時圖的 最大~最小 陰影區間（動態建立/移除）

        self.std_text_min = self.ax_min.text(0.02, 0.92, "", transform=self.ax_min.transAxes,
                                              fontsize=7, color="#333333")
        self.std_text_hour = self.ax_hour.text(0.02, 0.92, "", transform=self.ax_hour.transAxes,
                                                fontsize=7, color="#333333")

        # ---- 今日熱力圖（X:10分鐘區塊 0~50，Y:0~23時） ----
        self.ax_heat.set_title("今日各時段熱力圖 (10分鐘平均)", fontsize=11, fontweight="bold")
        init_grid = np.full((24, 6), np.nan)
        self.heatmap_im = self.ax_heat.imshow(init_grid, aspect="auto", cmap="YlOrRd",
                                               interpolation="nearest")
        self.ax_heat.set_xticks(range(6))
        self.ax_heat.set_xticklabels(["00", "10", "20", "30", "40", "50"], fontsize=7)
        self.ax_heat.set_yticks(range(0, 24, 2))
        self.ax_heat.set_yticklabels([f"{h:02d}" for h in range(0, 24, 2)], fontsize=7)
        self.ax_heat.set_xlabel("分鐘區塊", fontsize=8)
        self.ax_heat.set_ylabel("小時", fontsize=8)
        self.heatmap_cbar = self.fig.colorbar(self.heatmap_im, ax=self.ax_heat,
                                               fraction=0.046, pad=0.04)
        self.heatmap_cbar.ax.tick_params(labelsize=7)
        self.heatmap_cbar.set_label("°C", fontsize=8)

        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_holder)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def update_charts(self):
        r = self.recorder

        # 每秒
        y1 = list(r.sec_history)
        x1 = list(range(1, len(y1) + 1))
        self.line_sec.set_data(x1, y1)
        _autoscale(self.ax_sec, x1, y1, y1)

        # 每分(統計)：平均線 + 最大最小陰影帶
        stats2 = list(r.min_history)
        x2 = list(range(1, len(stats2) + 1))
        y2_mean = [s["mean"] for s in stats2]
        y2_max = [s["max"] for s in stats2]
        y2_min = [s["min"] for s in stats2]
        self.line_min.set_data(x2, y2_mean)
        if self.band_min is not None:
            self.band_min.remove()
            self.band_min = None
        if x2:
            self.band_min = self.ax_min.fill_between(x2, y2_min, y2_max, color="#c0504d", alpha=0.15)
            self.std_text_min.set_text(f"最新標準差 σ={stats2[-1]['std']:.2f}")
        else:
            self.std_text_min.set_text("")
        _autoscale(self.ax_min, x2, y2_min, y2_max)

        # 每時(統計)：平均線 + 最大最小陰影帶
        stats3 = list(r.hour_history)
        x3 = list(range(1, len(stats3) + 1))
        y3_mean = [s["mean"] for s in stats3]
        y3_max = [s["max"] for s in stats3]
        y3_min = [s["min"] for s in stats3]
        self.line_hour.set_data(x3, y3_mean)
        if self.band_hour is not None:
            self.band_hour.remove()
            self.band_hour = None
        if x3:
            self.band_hour = self.ax_hour.fill_between(x3, y3_min, y3_max, color="#8ab53f", alpha=0.15)
            self.std_text_hour.set_text(f"最新標準差 σ={stats3[-1]['std']:.2f}")
        else:
            self.std_text_hour.set_text("")
        _autoscale(self.ax_hour, x3, y3_min, y3_max)

        self.canvas.draw_idle()

    def update_heatmap(self):
        """依 recorder.today_minute_stats 重新計算「小時 x 10分鐘區塊」的平均溫度網格並更新熱力圖"""
        r = self.recorder
        sums = np.zeros((24, 6))
        counts = np.zeros((24, 6))
        for s in r.today_minute_stats:
            ts = s["timestamp"]  # "YYYYMMDDHHMM"
            hour = int(ts[8:10])
            minute = int(ts[10:12])
            block = minute // 10
            sums[hour, block] += s["mean"]
            counts[hour, block] += 1

        grid = np.full((24, 6), np.nan)
        mask = counts > 0
        grid[mask] = sums[mask] / counts[mask]

        self.heatmap_im.set_data(grid)
        valid = grid[~np.isnan(grid)]
        if valid.size > 0:
            self.heatmap_im.set_clim(vmin=float(valid.min()), vmax=float(valid.max()))
        self.canvas.draw_idle()

    def refresh_all(self):
        r = self.recorder
        self.count_label.config(
            text=f"今日已收集：{len(r.today_minute_stats)} 分鐘 / {len(r.hour_history)} 小時"
        )
        self.update_charts()
        self.update_heatmap()


class TempMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("溫度監控系統 - 模造區 / 洗淨區")
        self.root.geometry("1180x900")
        self.root.configure(bg="white")
        self.root.minsize(1000, 760)

        # ===== 建立兩職場的 recorder（純資料）與畫面元件參照 =====
        self.recorders = {
            wp["key"]: WorkplaceRecorder(wp["key"], wp["label"], DATA_DIR) for wp in WORKPLACES
        }
        for r in self.recorders.values():
            r.load_today_data()

        # ===== 上方：狀態/控制區塊 =====
        top = tk.Frame(root, bg="white", highlightbackground="black", highlightthickness=3)
        top.pack(side="top", fill="x", padx=10, pady=(10, 0))

        title = tk.Label(top, text="溫度監控系統", font=("Microsoft JhengHei", 20, "bold"),
                          bg="white", fg="black")
        title.grid(row=0, column=0, columnspan=8, sticky="w", padx=20, pady=(10, 4))

        # ---- 模造區 COM埠 / 連線控制 ----
        tk.Label(top, text="模造區 COM埠:", font=("Microsoft JhengHei", 11),
                 bg="white", fg="black").grid(row=1, column=0, sticky="w", padx=(20, 4), pady=4)

        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(top, textvariable=self.port_var, width=10,
                                        state="readonly", font=("Consolas", 10))
        self.port_combo.grid(row=1, column=1, sticky="w", pady=4)

        tk.Button(top, text="重新整理", command=self.refresh_ports,
                  font=("Microsoft JhengHei", 9)).grid(row=1, column=2, sticky="w", padx=6)

        self.connect_btn = tk.Button(top, text="連線", command=self.on_connect_clicked,
                                      font=("Microsoft JhengHei", 9, "bold"), bg="#e8f5e9")
        self.connect_btn.grid(row=1, column=3, sticky="w", padx=6)

        self.status_label = tk.Label(top, text="請選擇COM埠並按下連線", font=("Microsoft JhengHei", 9),
                                      bg="white", fg="gray")
        self.status_label.grid(row=1, column=4, columnspan=3, sticky="w", padx=10)

        self.mqtt_status_label = tk.Label(top, text="", font=("Microsoft JhengHei", 9),
                                           bg="white", fg="gray")
        self.mqtt_status_label.grid(row=2, column=0, columnspan=4, sticky="w", padx=(20, 4), pady=2)

        data_dir_label = tk.Label(top, text=f"資料儲存於: {DATA_DIR}", font=("Microsoft JhengHei", 8),
                                   bg="white", fg="gray")
        data_dir_label.grid(row=2, column=4, columnspan=4, sticky="w", padx=10)

        # ====== WiFi連線區塊：可彈性連到自己的WiFi裝置(手機熱點/隨身路由器)，不需要公司WiFi密碼 ======
        wifi_sep = tk.Frame(top, bg="#dddddd", height=1)
        wifi_sep.grid(row=3, column=0, columnspan=8, sticky="ew", padx=15, pady=(6, 4))

        tk.Label(top, text="WiFi:", font=("Microsoft JhengHei", 11),
                 bg="white", fg="black").grid(row=4, column=0, sticky="w", padx=(20, 4), pady=(0, 10))

        self.wifi_ssid_var = tk.StringVar()
        self.wifi_ssid_combo = ttk.Combobox(top, textvariable=self.wifi_ssid_var, width=16,
                                             font=("Consolas", 10))
        self.wifi_ssid_combo.grid(row=4, column=1, sticky="w", pady=(0, 10))

        tk.Button(top, text="掃描WiFi", command=self.scan_wifi_networks,
                  font=("Microsoft JhengHei", 9)).grid(row=4, column=2, sticky="w", padx=6)

        tk.Label(top, text="密碼:", font=("Microsoft JhengHei", 11),
                 bg="white", fg="black").grid(row=4, column=3, sticky="w")

        self.wifi_password_var = tk.StringVar()
        self.wifi_password_entry = tk.Entry(top, textvariable=self.wifi_password_var, width=16,
                                             font=("Consolas", 10), show="*")
        self.wifi_password_entry.grid(row=4, column=4, sticky="w")

        self.wifi_show_pw_var = tk.BooleanVar(value=False)
        tk.Checkbutton(top, text="顯示密碼", variable=self.wifi_show_pw_var, bg="white",
                        font=("Microsoft JhengHei", 8),
                        command=self._toggle_wifi_password_visibility).grid(row=4, column=5, sticky="w", padx=4)

        self.wifi_connect_btn = tk.Button(top, text="連線", command=self.connect_wifi,
                                           font=("Microsoft JhengHei", 9, "bold"), bg="#e3f2fd")
        self.wifi_connect_btn.grid(row=4, column=6, sticky="w", padx=6)

        self.wifi_status_label = tk.Label(top, text="尚未連線", font=("Microsoft JhengHei", 9),
                                           bg="white", fg="gray")
        self.wifi_status_label.grid(row=4, column=7, sticky="w", padx=6)

        # ===== 快速總覽區：兩職場目前溫度並排顯示，不用切分頁就能一眼看到 =====
        summary = tk.Frame(root, bg="white", highlightbackground="black", highlightthickness=3)
        summary.pack(side="top", fill="x", padx=10, pady=10)

        self.summary_widgets = {}
        for i, wp in enumerate(WORKPLACES):
            box = tk.Frame(summary, bg="white")
            box.grid(row=0, column=i, sticky="nsew", padx=20, pady=12)
            summary.grid_columnconfigure(i, weight=1)

            head = tk.Frame(box, bg="white")
            head.pack(anchor="w")
            dot = tk.Label(head, text="●", font=("Arial", 12), bg="white", fg="gray")
            dot.pack(side="left")
            tk.Label(head, text=wp["label"], font=("Microsoft JhengHei", 14, "bold"),
                     bg="white", fg="black").pack(side="left", padx=(4, 0))

            value_box = tk.Frame(box, bg="white", highlightbackground="black", highlightthickness=2)
            value_box.pack(anchor="w", pady=6)
            value_label = tk.Label(value_box, text="-- °C", font=("Consolas", 26, "bold"),
                                    bg="white", fg="black", width=8)
            value_label.pack(padx=10, pady=4)

            update_label = tk.Label(box, text="尚未收到資料", font=("Microsoft JhengHei", 8),
                                     bg="white", fg="gray")
            update_label.pack(anchor="w")

            self.summary_widgets[wp["key"]] = {"dot": dot, "value": value_label, "update": update_label}

        # ===== 下方：分頁籤，每個職場各一份完整圖表（每秒/每分/每時/今日熱力圖） =====
        notebook = ttk.Notebook(root)
        notebook.pack(side="top", fill="both", expand=True, padx=10, pady=(0, 10))

        self.panels = {}
        for wp in WORKPLACES:
            tab = tk.Frame(notebook, bg="white")
            notebook.add(tab, text=wp["label"])
            panel = WorkplaceChartPanel(tab, self.recorders[wp["key"]])
            panel.pack(fill="both", expand=True)
            self.panels[wp["key"]] = panel
            panel.refresh_all()

        self._refresh_summary()

        # 初始化COM埠下拉選單內容
        self.refresh_ports()

        # Modbus client 改為使用者按下「連線」按鈕後才建立，初始為None
        self.client = None

        # 洗淨區的溫度是透過MQTT背景執行緒(paho-mqtt的network loop)收到的，
        # 不能直接在該執行緒操作tkinter元件，所以先丟進這個queue，
        # 改由主執行緒的poll()每秒定期取出處理，確保所有tkinter操作都在主執行緒進行。
        self._washing_queue = queue.Queue()

        # 建立 MQTT 連線（若ENABLE_MQTT=False則完全不啟用，不影響原本純本地顯示功能）
        self.mqtt_client = None
        self.mqtt_connected = False
        self.last_publish_time = 0
        self.alert_active = {wp["key"]: False for wp in WORKPLACES}  # 各職場獨立追蹤是否已發送過警報，避免重複轟炸
        if ENABLE_MQTT:
            self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=MQTT_CLIENT_ID)
            self.mqtt_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
            self.mqtt_client.tls_set()

            def on_mqtt_connect(client, userdata, flags, reason_code, properties):
                if reason_code == 0:
                    self.mqtt_connected = True
                    self.mqtt_status_label.config(text="MQTT: 已連線", fg="green")
                    # 訂閱洗淨區(UNO R4)發布的溫度，訂閱成功後才收得到後續的每則訊息
                    client.subscribe(MQTT_TOPIC_WASHING, qos=1)
                else:
                    self.mqtt_connected = False
                    self.mqtt_status_label.config(
                        text=f"MQTT連線被拒絕(reason_code={reason_code})，請檢查HiveMQ帳密", fg="red"
                    )

            def on_mqtt_disconnect(client, userdata, flags, reason_code, properties):
                self.mqtt_connected = False
                self.mqtt_status_label.config(text="MQTT: 連線中斷", fg="orange")

            def on_mqtt_message(client, userdata, msg):
                # 這個callback是在paho-mqtt的背景執行緒被呼叫的，只做最單純的解析+放入queue，
                # 真正更新畫面的工作留給主執行緒的poll()去做，避免跨執行緒操作tkinter造成當機。
                try:
                    payload = json.loads(msg.payload.decode("utf-8"))
                    temp = float(payload["temperature_c"])
                    self._washing_queue.put(temp)
                except Exception as e:
                    print(f"洗淨區MQTT訊息解析失敗: {e}")

            self.mqtt_client.on_connect = on_mqtt_connect
            self.mqtt_client.on_disconnect = on_mqtt_disconnect
            self.mqtt_client.on_message = on_mqtt_message
            self.mqtt_client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            self.mqtt_client.loop_start()
        else:
            self.mqtt_status_label.config(text="MQTT未啟用(ENABLE_MQTT=False)，洗淨區將無法收到資料", fg="orange")

        self.poll()

    # ---------------------------------------------------------------------
    # COM埠 / Modbus連線（模造區專用，跟原本一致）
    # ---------------------------------------------------------------------
    def refresh_ports(self):
        """掃描目前電腦上可用的COM埠，更新下拉選單內容"""
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_combo["values"] = ports
        if not ports:
            self.port_var.set("")
            self.status_label.config(text="找不到任何COM埠，請確認USB-RS485轉換器已插上", fg="red")
            return
        if DEFAULT_SERIAL_PORT in ports:
            self.port_var.set(DEFAULT_SERIAL_PORT)
        else:
            self.port_var.set(ports[0])

    def on_connect_clicked(self):
        """使用者按下「連線」按鈕：關閉舊連線(若有)，用下拉選單選擇的COM埠重新建立連線"""
        selected_port = self.port_var.get()
        if not selected_port:
            self.status_label.config(text="請先選擇一個COM埠", fg="red")
            return

        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass

        self.status_label.config(text=f"正在連線 {selected_port} ...", fg="gray")
        self.client = ModbusSerialClient(
            port=selected_port, baudrate=BAUDRATE, parity=PARITY,
            stopbits=1, bytesize=8, timeout=1,
        )
        if self.client.connect():
            self.status_label.config(text=f"{selected_port} 連線成功", fg="green")
        else:
            self.status_label.config(text=f"{selected_port} 連線失敗，請確認COM埠是否正確", fg="red")

    # ---------------------------------------------------------------------
    # WiFi連線：讓使用者不需要知道電腦目前連的公司WiFi密碼，
    # 也能彈性切換連到自己的WiFi裝置(手機熱點/隨身路由器)
    # ---------------------------------------------------------------------
    def _toggle_wifi_password_visibility(self):
        """勾選「顯示密碼」時取消星號遮蔽，方便使用者確認打對了；預設維持遮蔽狀態"""
        self.wifi_password_entry.config(show="" if self.wifi_show_pw_var.get() else "*")

    def scan_wifi_networks(self):
        """呼叫 netsh wlan show networks 掃描附近可連線的WiFi SSID，填入下拉選單供選擇"""
        self.wifi_status_label.config(text="掃描中...", fg="gray")
        self.root.update_idletasks()
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "networks"],
                capture_output=True, text=True, errors="ignore", timeout=10,
            )
            ssids = []
            for line in result.stdout.splitlines():
                line = line.strip()
                # netsh輸出格式例如「SSID 1 : MyWifiName」，中英文Windows版本前綴文字略有不同，
                # 統一用「以SSID開頭 + 冒號分隔」的規則來抓取，較不受語系影響
                if line.upper().startswith("SSID") and ":" in line:
                    ssid = line.split(":", 1)[1].strip()
                    if ssid and ssid not in ssids:
                        ssids.append(ssid)

            self.wifi_ssid_combo["values"] = ssids
            if ssids:
                self.wifi_ssid_var.set(ssids[0])
                self.wifi_status_label.config(text=f"掃描到 {len(ssids)} 個WiFi訊號", fg="gray")
            else:
                self.wifi_status_label.config(
                    text="沒有掃描到WiFi，請確認電腦WiFi功能已開啟", fg="red"
                )
        except FileNotFoundError:
            self.wifi_status_label.config(text="找不到netsh指令(僅支援Windows)", fg="red")
        except Exception as e:
            self.wifi_status_label.config(text=f"掃描失敗: {e}", fg="red")

    def connect_wifi(self):
        """把使用者輸入的SSID/密碼包成WLAN設定檔，透過netsh匯入並連線"""
        ssid = self.wifi_ssid_var.get().strip()
        password = self.wifi_password_var.get()

        if not ssid:
            self.wifi_status_label.config(text="請輸入或選擇SSID", fg="red")
            return
        if password and len(password) < 8:
            # WPA2-Personal密碼規範為8~63個字元，太短一定會連線失敗，先在畫面上提醒
            self.wifi_status_label.config(text="密碼長度需至少8碼(WPA2規範)", fg="red")
            return

        self.wifi_status_label.config(text="正在連線...", fg="gray")
        self.root.update_idletasks()

        profile_xml = WIFI_PROFILE_TEMPLATE.format(
            ssid=xml_escape(ssid), password=xml_escape(password)
        )
        profile_path = os.path.join(tempfile.gettempdir(), f"wifi_profile_{int(time.time())}.xml")

        try:
            with open(profile_path, "w", encoding="utf-8") as f:
                f.write(profile_xml)

            add_result = subprocess.run(
                ["netsh", "wlan", "add", "profile", f"filename={profile_path}"],
                capture_output=True, text=True, errors="ignore", timeout=10,
            )
            if add_result.returncode != 0:
                msg = (add_result.stdout or add_result.stderr or "未知錯誤").strip()
                self.wifi_status_label.config(
                    text=f"新增設定檔失敗，可能需要系統管理員權限: {msg[:60]}", fg="red"
                )
                return

            connect_result = subprocess.run(
                ["netsh", "wlan", "connect", f"name={ssid}", f"ssid={ssid}"],
                capture_output=True, text=True, errors="ignore", timeout=15,
            )
            if connect_result.returncode == 0:
                self.wifi_status_label.config(text=f"已送出連線請求: {ssid}", fg="green")
            else:
                msg = (connect_result.stdout or connect_result.stderr or "未知錯誤").strip()
                self.wifi_status_label.config(text=f"連線失敗: {msg[:60]}", fg="red")
        except FileNotFoundError:
            self.wifi_status_label.config(text="找不到netsh指令(僅支援Windows)", fg="red")
        except Exception as e:
            self.wifi_status_label.config(text=f"發生錯誤: {e}", fg="red")
        finally:
            try:
                os.remove(profile_path)
            except Exception:
                pass

    # ---------------------------------------------------------------------
    # 溫度處理共用邏輯：記錄、更新畫面、超溫警報
    # ---------------------------------------------------------------------
    def _handle_new_reading(self, key: str, temp: float):
        recorder = self.recorders[key]
        recorder.record(temp)
        self.panels[key].refresh_all()
        self._check_alert(key, temp)

    def _check_alert(self, key: str, temp: float):
        label = next(wp["label"] for wp in WORKPLACES if wp["key"] == key)
        if temp > TEMP_HIGH_THRESHOLD and not self.alert_active[key]:
            self.alert_active[key] = True
            alert_text = (f"職場: {label}\n目前溫度: {temp:.1f}°C\n"
                           f"已超過設定上限: {TEMP_HIGH_THRESHOLD}°C")
            if ENABLE_TELEGRAM:
                send_telegram_message(f"⚠️ 溫度警報\n{alert_text}")
            if ENABLE_EMAIL:
                send_email_alert(f"【溫度警報】{label} Azbil C15溫控器超溫", alert_text)
        elif temp <= TEMP_HIGH_THRESHOLD - ALERT_HYSTERESIS:
            self.alert_active[key] = False

    def _refresh_summary(self):
        """更新頂部快速總覽的兩個溫度框：目前溫度、最後更新時間、上線狀態燈號"""
        # 判斷「離線」的門檻：超過3個輪詢週期沒收到新資料就視為離線(molding: 沒連線/讀取失敗；washing: MQTT斷線或UNO R4離線)
        stale_after = (POLL_INTERVAL_MS / 1000.0) * 3
        for wp in WORKPLACES:
            key = wp["key"]
            recorder = self.recorders[key]
            widgets = self.summary_widgets[key]
            if recorder.latest_temp is not None:
                widgets["value"].config(text=f"{recorder.latest_temp:.1f} °C")
                widgets["update"].config(
                    text=f"最後更新: {recorder.latest_update_time.strftime('%H:%M:%S')}"
                )
            if recorder.is_online(stale_after):
                widgets["dot"].config(fg="#3ea55f")
            else:
                widgets["dot"].config(fg="#b0b0b0")

    # ---------------------------------------------------------------------
    # 輪詢主迴圈：處理模造區(本機Modbus)讀取 + 洗淨區(MQTT queue)收取
    # ---------------------------------------------------------------------
    def poll(self):
        # ---- 模造區：本機透過RS485讀取 ----
        if self.client is None:
            pass
        elif not self.client.connected:
            self.status_label.config(text="連線中斷，嘗試重新連線...", fg="orange")
            try:
                self.client.close()
            except Exception:
                pass
            try:
                if self.client.connect():
                    self.status_label.config(text="重新連線成功", fg="green")
            except Exception as e:
                self.status_label.config(text=f"重新連線失敗: {e}", fg="red")
        else:
            try:
                rr = self.client.read_holding_registers(
                    address=PV_REGISTER, count=1, device_id=SLAVE_ID
                )
                if rr.isError():
                    self.status_label.config(text=f"讀取錯誤: {rr}", fg="red")
                else:
                    raw = rr.registers[0]
                    if raw >= 0x8000:  # 負溫度的16bit補數轉換
                        raw -= 0x10000
                    temp = raw / (10 ** DECIMALS)
                    self.status_label.config(text="連線正常", fg="green")

                    self._handle_new_reading("molding", temp)

                    # 發布模造區溫度到 MQTT（若啟用），依 MQTT_PUBLISH_INTERVAL_SEC 控制發送頻率
                    if self.mqtt_client is not None:
                        now = time.time()
                        if now - self.last_publish_time >= MQTT_PUBLISH_INTERVAL_SEC:
                            self.last_publish_time = now
                            payload = {
                                "device": "azbil_c15tv0ta030a",
                                "area": "molding",
                                "temperature_c": temp,
                                "timestamp": int(now),
                            }
                            try:
                                self.mqtt_client.publish(
                                    MQTT_TOPIC_MOLDING, json.dumps(payload), qos=1, retain=True
                                )
                            except Exception:
                                pass
            except Exception as e:
                self.status_label.config(text=f"通訊中斷，準備重新連線: {e}", fg="red")
                try:
                    self.client.close()
                except Exception:
                    pass

        # ---- 洗淨區：從MQTT queue取出UNO R4回報的溫度(可能一次累積好幾筆) ----
        while True:
            try:
                temp = self._washing_queue.get_nowait()
            except queue.Empty:
                break
            self._handle_new_reading("washing", temp)

        self._refresh_summary()
        self.root.after(POLL_INTERVAL_MS, self.poll)

    def on_close(self):
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass
        if self.mqtt_client is not None:
            try:
                self.mqtt_client.loop_stop()
                self.mqtt_client.disconnect()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = TempMonitorApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
