# 溫度監控系統 — 模造區 / 洗淨區整合

三個部分整合成一套系統：

| 檔案 | 執行位置 | 功能 |
|---|---|---|
| `uno_r4_firmware.ino` | UNO R4 WiFi（洗淨區） | 讀RS485溫控器 → 發布到 MQTT `azbil/c15/temperature/washing` |
| `gui_monitor.py` | PC（模造區） | 本機RS485讀模造區 → 發布到 `azbil/c15/temperature/molding`；同時訂閱`.../washing`，畫面同時顯示兩職場 |
| `cloud_dashboard/index.html` | GitHub Pages（雲端） | 純前端網頁，訂閱兩個topic，手機瀏覽器打開即可即時監看 |

三者透過同一個 HiveMQ Cloud Broker 溝通，靠 **topic路徑** 分辨資料屬於哪個職場：

```
azbil/c15/temperature/molding   <- gui_monitor.py 發布
azbil/c15/temperature/washing   <- UNO R4 發布
```

---

## 1. 燒錄 UNO R4 韌體（洗淨區）

跟原本流程一樣，`uno_r4_firmware.ino` 只多了兩個修改：
- MQTT topic 改成 `azbil/c15/temperature/washing`
- JSON payload多了 `"area": "washing"` 欄位

上傳前確認「使用者設定」區塊的 WiFi SSID/密碼、HiveMQ帳密等都正確即可。

## 2. 執行 PC端 GUI（模造區 + 整合顯示）

```
pip install pymodbus pyserial paho-mqtt matplotlib numpy
python gui_monitor.py
```

畫面上方會同時顯示「模造區」「洗淨區」目前溫度與連線燈號，下方分頁籤可分別看兩職場各自完整的
每秒/每分/每時/今日熱力圖。模造區要按下「連線」選COM埠才會開始讀值；洗淨區則是被動接收UNO R4發來的
MQTT訊息，只要MQTT連線正常、UNO R4也在跑，畫面就會自動更新，不需要額外操作。

CSV記錄檔會依「職場+日期」分開存放在 `temp_logs/` 資料夾，例如：
```
temp_logs/raw_molding_20260717.csv
temp_logs/raw_washing_20260717.csv
```

## 3. 部署雲端 Dashboard（GitHub Pages，手機隨時看）

### 3.1 先在 HiveMQ Cloud 建立一組「唯讀」帳密（重要，務必先做）

`cloud_dashboard/index.html` 是純前端網頁，程式碼會整個公開在GitHub上，**不能**放你原本
`gui_monitor.py` / `uno_r4_firmware.ino` 裡那組有讀寫權限的帳密，否則任何人打開瀏覽器
「檢視原始碼」都能拿到帳密去操控你的Broker。

步驟：
1. 登入 HiveMQ Cloud 主控台 → 選擇你的Cluster → **Access Management**
2. **Add new credentials**，設定：
   - Username / Password：自訂一組新的（例如 `dashboard-viewer`）
   - Permissions：新增一條規則
     - Topic: `azbil/c15/temperature/#`
     - Permission: **Subscribe only**（絕對不要勾 Publish）
3. 儲存

### 3.2 填入設定

打開 `cloud_dashboard/index.html`，找到接近檔案最下方的 `CONFIG` 區塊：

```js
const CONFIG = {
  host: "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud",  // 跟gui_monitor.py的MQTT_HOST一致
  port: 8884,        // HiveMQ Cloud WebSocket固定埠，不用改
  path: "/mqtt",      // HiveMQ Cloud WebSocket固定路徑，不用改
  username: "REPLACE_WITH_READONLY_USERNAME",   // 換成3.1建立的唯讀帳號
  password: "REPLACE_WITH_READONLY_PASSWORD",   // 換成3.1建立的唯讀密碼
};
```

把 `username` / `password` 換成剛剛建立的唯讀帳密即可。

### 3.3 放到 GitHub 並開啟 Pages

1. 建一個新的GitHub repo（可以是public，因為裡面已經沒有敏感帳密了），把整個
   `cloud_dashboard/` 資料夾內容(至少`index.html`)放進去，push上去
2. repo頁面 → **Settings → Pages**
3. Source 選擇你放檔案的分支(例如`main`)，資料夾選 `/ (root)`（如果`index.html`直接在repo根目錄）
4. 存檔後，GitHub會給你一個網址，格式類似：
   ```
   https://你的帳號.github.io/repo名稱/
   ```
5. 手機打開這個網址，加到主畫面（iOS: 分享→加入主畫面；Android: 選單→加到主畫面），
   之後就像App一樣可以隨時點開看

---

## 溫度警報門檻

`gui_monitor.py` 裡的 `TEMP_HIGH_THRESHOLD`（目前30.0°C）跟 `cloud_dashboard/index.html`
裡的 `TEMP_HIGH_THRESHOLD` 是各自獨立的常數，兩邊改動時記得同步，否則PC端跟手機端看到的
「超溫標紅」門檻會不一致（PC端超溫還會另外觸發Email/Telegram警報，網頁端目前只是把數字顯示變紅，
沒有另外做推播）。
