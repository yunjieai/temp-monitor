
import sys
import time
import json
import ssl
import csv
import os
import statistics
import smtplib
import datetime
import subprocess
import tempfile
from xml.sax.saxutils import escape as xml_escape
from collections import deque
from email.mime.text import MIMEText
import urllib.request
import urllib.parse
import tkinter as tk
from tkinter import ttk
import serial.tools.list_ports
from pymodbus.client import ModbusSerialClient
import paho.mqtt.client as mqtt
import numpy as np

import matplotlib
matplotlib.use("TkAgg")
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "SimHei", "Arial Unicode MS"]
matplotlib.rcParams["axes.unicode_minus"] = False
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

try:
    import truststore
    _TELEGRAM_SSL_CONTEXT = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
except ImportError:
    print("提醒：尚未安裝 truststore，若Telegram發送出現SSL憑證錯誤，"
          "請執行: python -m pip install truststore")
    _TELEGRAM_SSL_CONTEXT = ssl.create_default_context()

DEFAULT_SERIAL_PORT = "COM8"
BAUDRATE = 9600
PARITY = "O"
SLAVE_ID = 1
PV_REGISTER = 0x238D
DECIMALS = 0
POLL_INTERVAL_MS = 1000

SEC_HISTORY_LEN = 60
MIN_HISTORY_LEN = 60
HOUR_HISTORY_LEN = 24

if getattr(sys, "frozen", False):
    _BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    _BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(_BASE_DIR, "temp_logs")
os.makedirs(DATA_DIR, exist_ok=True)

ENABLE_MQTT = True
MQTT_HOST = "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USERNAME = "temp"
MQTT_PASSWORD = "temp0001"
MQTT_TOPIC = "azbil/c15/temperature"
MQTT_CLIENT_ID = "gui-monitor-publisher"
MQTT_PUBLISH_INTERVAL_SEC = 2

ENABLE_TELEGRAM = False
TELEGRAM_BOT_TOKEN = "8339192759:AAE4vXsQZ3GcuzA_sRu3XiAuzfeMde6dQ24"
TELEGRAM_CHAT_ID = "8987703678"

ENABLE_EMAIL = True
SMTP_HOST = "smtp.office365.com"
SMTP_PORT = 587
SMTP_USE_TLS = True
SMTP_REQUIRE_AUTH = True
SMTP_USERNAME = "you@yourcompany.com"
SMTP_PASSWORD = "your_email_password"
EMAIL_FROM = "you@yourcompany.com"
EMAIL_TO = "you@yourcompany.com"

TEMP_HIGH_THRESHOLD = 30.0
ALERT_HYSTERESIS = 1.0

WIFI_PROFILE_TEMPLATE = """<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <name>{ssid}</name>
    <SSIDConfig>
        <SSID>
            <name>{ssid}</name>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>manual</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>{password}</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>
"""


def send_telegram_message(text: str) -> bool:
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": TELEGRAM_CHAT_ID, "text": text}).encode("utf-8")
    try:
        handler = urllib.request.HTTPSHandler(context=_TELEGRAM_SSL_CONTEXT)
        opener = urllib.request.build_opener(handler)
        req = urllib.request.Request(url, data=data)
        with opener.open(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"Telegram發送失敗: {e}")
        return False


def send_email_alert(subject: str, body: str) -> bool:
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = EMAIL_TO

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as server:
            if SMTP_USE_TLS:
                server.starttls()
            if SMTP_REQUIRE_AUTH:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, [EMAIL_TO], msg.as_string())
        return True
    except Exception as e:
        print(f"Email發送失敗: {e}")
        return False


def _raw_csv_path(d: datetime.date) -> str:
    return os.path.join(DATA_DIR, f"raw_{d.strftime('%Y%m%d')}.csv")


def _minute_csv_path(d: datetime.date) -> str:
    return os.path.join(DATA_DIR, f"minute_stats_{d.strftime('%Y%m%d')}.csv")


def _hour_csv_path(d: datetime.date) -> str:
    return os.path.join(DATA_DIR, f"hour_stats_{d.strftime('%Y%m%d')}.csv")


def _append_csv_row(path: str, header, row):
    is_new = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if is_new:
            writer.writerow(header)
        writer.writerow(row)


def _compute_stats(values) -> dict:
    return {
        "mean": statistics.mean(values),
        "max": max(values),
        "min": min(values),
        "std": statistics.pstdev(values),
        "count": len(values),
    }


class TempMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("溫度監控系統")
        self.root.geometry("1150x730")
        self.root.configure(bg="white")
        self.root.resizable(False, False)

        top = tk.Frame(root, bg="white", highlightbackground="black", highlightthickness=3)
        top.place(x=10, y=10, width=1130, height=210)

        title = tk.Label(top, text="溫度監控系統", font=("Microsoft JhengHei", 20, "bold"),
                          bg="white", fg="black")
        title.place(x=20, y=10)

        label = tk.Label(top, text="環境溫度:", font=("Microsoft JhengHei", 14),
                          bg="white", fg="black")
        label.place(x=20, y=65)

        value_box = tk.Frame(top, bg="white", highlightbackground="black", highlightthickness=2)
        value_box.place(x=130, y=57, width=120, height=42)
        self.value_label = tk.Label(value_box, text="--", font=("Consolas", 18, "bold"),
                                     bg="white", fg="black")
        self.value_label.place(relx=0.5, rely=0.5, anchor="center")

        unit_label = tk.Label(top, text="度", font=("Microsoft JhengHei", 14),
                               bg="white", fg="black")
        unit_label.place(x=260, y=65)

        port_label = tk.Label(top, text="COM埠:", font=("Microsoft JhengHei", 11),
                               bg="white", fg="black")
        port_label.place(x=350, y=68)

        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(top, textvariable=self.port_var, width=10,
                                        state="readonly", font=("Consolas", 10))
        self.port_combo.place(x=415, y=68)

        refresh_btn = tk.Button(top, text="重新整理", command=self.refresh_ports,
                                 font=("Microsoft JhengHei", 9))
        refresh_btn.place(x=530, y=65)

        self.connect_btn = tk.Button(top, text="連線", command=self.on_connect_clicked,
                                      font=("Microsoft JhengHei", 9, "bold"), bg="#e8f5e9")
        self.connect_btn.place(x=610, y=65)

        self.status_label = tk.Label(top, text="請選擇COM埠並按下連線", font=("Microsoft JhengHei", 9),
                                      bg="white", fg="gray")
        self.status_label.place(x=20, y=115)

        self.mqtt_status_label = tk.Label(top, text="", font=("Microsoft JhengHei", 9),
                                           bg="white", fg="gray")
        self.mqtt_status_label.place(x=20, y=137)

        data_dir_label = tk.Label(top, text=f"資料儲存於: {DATA_DIR}", font=("Microsoft JhengHei", 8),
                                   bg="white", fg="gray")
        data_dir_label.place(x=350, y=115)

        self.today_count_label = tk.Label(top, text="", font=("Microsoft JhengHei", 8),
                                           bg="white", fg="gray")
        self.today_count_label.place(x=350, y=137)

        wifi_sep = tk.Frame(top, bg="#dddddd", height=1)
        wifi_sep.place(x=15, y=157, width=1100)

        wifi_label = tk.Label(top, text="WiFi:", font=("Microsoft JhengHei", 11),
                               bg="white", fg="black")
        wifi_label.place(x=20, y=168)

        self.wifi_ssid_var = tk.StringVar()
        self.wifi_ssid_combo = ttk.Combobox(top, textvariable=self.wifi_ssid_var, width=18,
                                             font=("Consolas", 10))
        self.wifi_ssid_combo.place(x=65, y=168)

        wifi_scan_btn = tk.Button(top, text="掃描WiFi", command=self.scan_wifi_networks,
                                   font=("Microsoft JhengHei", 9))
        wifi_scan_btn.place(x=225, y=165)

        wifi_pw_label = tk.Label(top, text="密碼:", font=("Microsoft JhengHei", 11),
                                  bg="white", fg="black")
        wifi_pw_label.place(x=320, y=168)

        self.wifi_password_var = tk.StringVar()
        self.wifi_password_entry = tk.Entry(top, textvariable=self.wifi_password_var, width=18,
                                             font=("Consolas", 10), show="*")
        self.wifi_password_entry.place(x=365, y=168)

        self.wifi_show_pw_var = tk.BooleanVar(value=False)
        wifi_show_pw_check = tk.Checkbutton(
            top, text="顯示密碼", variable=self.wifi_show_pw_var, bg="white",
            font=("Microsoft JhengHei", 8), command=self._toggle_wifi_password_visibility,
        )
        wifi_show_pw_check.place(x=525, y=167)

        self.wifi_connect_btn = tk.Button(top, text="連線", command=self.connect_wifi,
                                           font=("Microsoft JhengHei", 9, "bold"), bg="#e3f2fd")
        self.wifi_connect_btn.place(x=615, y=165)

        self.wifi_status_label = tk.Label(top, text="尚未連線", font=("Microsoft JhengHei", 9),
                                           bg="white", fg="gray")
        self.wifi_status_label.place(x=680, y=168)

        chart_frame = tk.Frame(root, bg="white", highlightbackground="black", highlightthickness=3)
        chart_frame.place(x=10, y=230, width=1130, height=480)

        self.fig = Figure(figsize=(11.2, 4.7), dpi=100)
        gs = self.fig.add_gridspec(2, 2, hspace=0.55, wspace=0.3)
        self.ax_sec = self.fig.add_subplot(gs[0, 0])
        self.ax_min = self.fig.add_subplot(gs[0, 1])
        self.ax_hour = self.fig.add_subplot(gs[1, 0])
        self.ax_heat = self.fig.add_subplot(gs[1, 1])

        self.ax_sec.set_title("每秒", fontsize=11, fontweight="bold")
        self.ax_min.set_title("每分(平均/最大/最小)", fontsize=11, fontweight="bold")
        self.ax_hour.set_title("每時(平均/最大/最小)", fontsize=11, fontweight="bold")
        for ax in (self.ax_sec, self.ax_min, self.ax_hour):
            ax.grid(True, linewidth=0.5, alpha=0.6)
            ax.tick_params(labelsize=7)

        (self.line_sec,) = self.ax_sec.plot([], [], color="#4a7ebb", linewidth=1.2)
        (self.line_min,) = self.ax_min.plot([], [], color="#c0504d", linewidth=1.2, label="平均")
        (self.line_hour,) = self.ax_hour.plot([], [], color="#8ab53f", linewidth=1.2, label="平均")
        self.band_min = None
        self.band_hour = None

        self.std_text_min = self.ax_min.text(0.02, 0.92, "", transform=self.ax_min.transAxes,
                                              fontsize=7, color="#333333")
        self.std_text_hour = self.ax_hour.text(0.02, 0.92, "", transform=self.ax_hour.transAxes,
                                                fontsize=7, color="#333333")

        self.ax_heat.set_title("今日各時段熱力圖 (10分鐘平均)", fontsize=11, fontweight="bold")
        init_grid = np.full((24, 6), np.nan)
        self.heatmap_im = self.ax_heat.imshow(init_grid, aspect="auto", cmap="YlOrRd",
                                               interpolation="nearest")
        self.ax_heat.set_xticks(range(6))
        self.ax_heat.set_xticklabels(["00", "10", "20", "30", "40", "50"], fontsize=7)
        self.ax_heat.set_yticks(range(0, 24, 2))
        self.ax_heat.set_yticklabels([f"{h:02d}" for h in range(0, 24, 2)], fontsize=7)
        self.ax_heat.set_xlabel("分鐘區塊", fontsize=8)
        self.ax_heat.set_ylabel("小時", fontsize=8)
        self.heatmap_cbar = self.fig.colorbar(self.heatmap_im, ax=self.ax_heat,
                                               fraction=0.046, pad=0.04)
        self.heatmap_cbar.ax.tick_params(labelsize=7)
        self.heatmap_cbar.set_label("°C", fontsize=8)

        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_frame)
        self.canvas.get_tk_widget().place(x=5, y=5, width=1115, height=470)

        self.sec_history = deque(maxlen=SEC_HISTORY_LEN)
        self.min_history = deque(maxlen=MIN_HISTORY_LEN)
        self.hour_history = deque(maxlen=HOUR_HISTORY_LEN)
        self.today_minute_stats = []

        self._minute_buffer = []
        self._current_minute_key = None
        self._hour_buffer = []
        self._current_hour_key = None
        self.today_date = datetime.date.today()

        self._load_today_data()
        self._update_charts()
        self._update_heatmap()

        self.refresh_ports()

        self.client = None

        self.mqtt_client = None
        self.mqtt_connected = False
        self.last_publish_time = 0
        self.alert_active = False
        if ENABLE_MQTT:
            self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=MQTT_CLIENT_ID)
            self.mqtt_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
            self.mqtt_client.tls_set()

            def on_mqtt_connect(client, userdata, flags, reason_code, properties):
                if reason_code == 0:
                    self.mqtt_connected = True
                    self.mqtt_status_label.config(text="MQTT: 已連線", fg="green")
                else:
                    self.mqtt_connected = False
                    self.mqtt_status_label.config(
                        text=f"MQTT連線被拒絕(reason_code={reason_code})，請檢查HiveMQ帳密", fg="red"
                    )

            def on_mqtt_disconnect(client, userdata, flags, reason_code, properties):
                self.mqtt_connected = False
                self.mqtt_status_label.config(text="MQTT: 連線中斷", fg="orange")

            self.mqtt_client.on_connect = on_mqtt_connect
            self.mqtt_client.on_disconnect = on_mqtt_disconnect
            self.mqtt_client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            self.mqtt_client.loop_start()

        self.poll()

    def refresh_ports(self):
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_combo["values"] = ports
        if not ports:
            self.port_var.set("")
            self.status_label.config(text="找不到任何COM埠，請確認USB-RS485轉換器已插上", fg="red")
            return
        if DEFAULT_SERIAL_PORT in ports:
            self.port_var.set(DEFAULT_SERIAL_PORT)
        else:
            self.port_var.set(ports[0])

    def on_connect_clicked(self):
        selected_port = self.port_var.get()
        if not selected_port:
            self.status_label.config(text="請先選擇一個COM埠", fg="red")
            return

        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass

        self.status_label.config(text=f"正在連線 {selected_port} ...", fg="gray")
        self.client = ModbusSerialClient(
            port=selected_port, baudrate=BAUDRATE, parity=PARITY,
            stopbits=1, bytesize=8, timeout=1,
        )
        if self.client.connect():
            self.status_label.config(text=f"{selected_port} 連線成功", fg="green")
        else:
            self.status_label.config(text=f"{selected_port} 連線失敗，請確認COM埠是否正確", fg="red")

    def _toggle_wifi_password_visibility(self):
        self.wifi_password_entry.config(show="" if self.wifi_show_pw_var.get() else "*")

    def scan_wifi_networks(self):
        self.wifi_status_label.config(text="掃描中...", fg="gray")
        self.root.update_idletasks()
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "networks"],
                capture_output=True, text=True, errors="ignore", timeout=10,
            )
            ssids = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.upper().startswith("SSID") and ":" in line:
                    ssid = line.split(":", 1)[1].strip()
                    if ssid and ssid not in ssids:
                        ssids.append(ssid)

            self.wifi_ssid_combo["values"] = ssids
            if ssids:
                self.wifi_ssid_var.set(ssids[0])
                self.wifi_status_label.config(text=f"掃描到 {len(ssids)} 個WiFi訊號", fg="gray")
            else:
                self.wifi_status_label.config(
                    text="沒有掃描到WiFi，請確認電腦WiFi功能已開啟", fg="red"
                )
        except FileNotFoundError:
            self.wifi_status_label.config(text="找不到netsh指令(僅支援Windows)", fg="red")
        except Exception as e:
            self.wifi_status_label.config(text=f"掃描失敗: {e}", fg="red")

    def connect_wifi(self):
        ssid = self.wifi_ssid_var.get().strip()
        password = self.wifi_password_var.get()

        if not ssid:
            self.wifi_status_label.config(text="請輸入或選擇SSID", fg="red")
            return
        if password and len(password) < 8:
            self.wifi_status_label.config(text="密碼長度需至少8碼(WPA2規範)", fg="red")
            return

        self.wifi_status_label.config(text="正在連線...", fg="gray")
        self.root.update_idletasks()

        profile_xml = WIFI_PROFILE_TEMPLATE.format(
            ssid=xml_escape(ssid), password=xml_escape(password)
        )
        profile_path = os.path.join(tempfile.gettempdir(), f"wifi_profile_{int(time.time())}.xml")

        try:
            with open(profile_path, "w", encoding="utf-8") as f:
                f.write(profile_xml)

            add_result = subprocess.run(
                ["netsh", "wlan", "add", "profile", f"filename={profile_path}"],
                capture_output=True, text=True, errors="ignore", timeout=10,
            )
            if add_result.returncode != 0:
                msg = (add_result.stdout or add_result.stderr or "未知錯誤").strip()
                self.wifi_status_label.config(
                    text=f"新增設定檔失敗，可能需要系統管理員權限: {msg[:60]}", fg="red"
                )
                return

            connect_result = subprocess.run(
                ["netsh", "wlan", "connect", f"name={ssid}", f"ssid={ssid}"],
                capture_output=True, text=True, errors="ignore", timeout=15,
            )
            if connect_result.returncode == 0:
                self.wifi_status_label.config(text=f"已送出連線請求: {ssid}", fg="green")
            else:
                msg = (connect_result.stdout or connect_result.stderr or "未知錯誤").strip()
                self.wifi_status_label.config(text=f"連線失敗: {msg[:60]}", fg="red")
        except FileNotFoundError:
            self.wifi_status_label.config(text="找不到netsh指令(僅支援Windows)", fg="red")
        except Exception as e:
            self.wifi_status_label.config(text=f"發生錯誤: {e}", fg="red")
        finally:
            try:
                os.remove(profile_path)
            except Exception:
                pass

    def _load_today_data(self):
        minute_path = _minute_csv_path(self.today_date)
        if os.path.exists(minute_path):
            try:
                with open(minute_path, newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        stats = {
                            "timestamp": row["分鐘(YYYYMMDDHHMM)"],
                            "mean": float(row["平均"]),
                            "max": float(row["最大"]),
                            "min": float(row["最小"]),
                            "std": float(row["標準差"]),
                            "count": int(row["樣本數"]),
                        }
                        self.min_history.append(stats)
                        self.today_minute_stats.append(stats)
            except Exception as e:
                print(f"讀取今日分鐘統計CSV失敗，將略過: {e}")

        hour_path = _hour_csv_path(self.today_date)
        if os.path.exists(hour_path):
            try:
                with open(hour_path, newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        stats = {
                            "timestamp": row["小時(YYYYMMDDHH)"],
                            "mean": float(row["平均"]),
                            "max": float(row["最大"]),
                            "min": float(row["最小"]),
                            "std": float(row["標準差"]),
                            "count": int(row["樣本數"]),
                        }
                        self.hour_history.append(stats)
            except Exception as e:
                print(f"讀取今日小時統計CSV失敗，將略過: {e}")

        self.today_count_label.config(
            text=f"今日已收集：{len(self.today_minute_stats)} 分鐘 / {len(self.hour_history)} 小時"
        )

    def _start_new_day(self, new_date: datetime.date):
        self.today_date = new_date
        self.today_minute_stats = []
        self.today_count_label.config(text="今日已收集：0 分鐘 / 0 小時")
        self._update_heatmap()

    def _record_temperature(self, temp: float):
        now = datetime.datetime.now()

        if now.date() != self.today_date:
            self._start_new_day(now.date())

        self.sec_history.append(temp)
        _append_csv_row(
            _raw_csv_path(self.today_date),
            ["時間戳", "溫度(°C)"],
            [now.strftime("%Y-%m-%d %H:%M:%S"), f"{temp:.1f}"],
        )

        minute_key = now.strftime("%Y%m%d%H%M")
        if self._current_minute_key is None:
            self._current_minute_key = minute_key
        if minute_key != self._current_minute_key:
            if self._minute_buffer:
                stats = _compute_stats(self._minute_buffer)
                stats["timestamp"] = self._current_minute_key
                self.min_history.append(stats)
                self.today_minute_stats.append(stats)
                _append_csv_row(
                    _minute_csv_path(self.today_date),
                    ["分鐘(YYYYMMDDHHMM)", "平均", "最大", "最小", "標準差", "樣本數"],
                    [stats["timestamp"], f"{stats['mean']:.2f}", f"{stats['max']:.1f}",
                     f"{stats['min']:.1f}", f"{stats['std']:.2f}", stats["count"]],
                )
                self._update_heatmap()
                self.today_count_label.config(
                    text=f"今日已收集：{len(self.today_minute_stats)} 分鐘 / {len(self.hour_history)} 小時"
                )
            self._minute_buffer = []
            self._current_minute_key = minute_key
        self._minute_buffer.append(temp)

        hour_key = now.strftime("%Y%m%d%H")
        if self._current_hour_key is None:
            self._current_hour_key = hour_key
        if hour_key != self._current_hour_key:
            if self._hour_buffer:
                hstats = _compute_stats(self._hour_buffer)
                hstats["timestamp"] = self._current_hour_key
                self.hour_history.append(hstats)
                _append_csv_row(
                    _hour_csv_path(self.today_date),
                    ["小時(YYYYMMDDHH)", "平均", "最大", "最小", "標準差", "樣本數"],
                    [hstats["timestamp"], f"{hstats['mean']:.2f}", f"{hstats['max']:.1f}",
                     f"{hstats['min']:.1f}", f"{hstats['std']:.2f}", hstats["count"]],
                )
            self._hour_buffer = []
            self._current_hour_key = hour_key
        self._hour_buffer.append(temp)

        self._update_charts()

    def _update_charts(self):
        y1 = list(self.sec_history)
        x1 = list(range(1, len(y1) + 1))
        self.line_sec.set_data(x1, y1)
        self._autoscale(self.ax_sec, x1, y1, y1)

        stats2 = list(self.min_history)
        x2 = list(range(1, len(stats2) + 1))
        y2_mean = [s["mean"] for s in stats2]
        y2_max = [s["max"] for s in stats2]
        y2_min = [s["min"] for s in stats2]
        self.line_min.set_data(x2, y2_mean)
        if self.band_min is not None:
            self.band_min.remove()
            self.band_min = None
        if x2:
            self.band_min = self.ax_min.fill_between(x2, y2_min, y2_max, color="#c0504d", alpha=0.15)
            self.std_text_min.set_text(f"最新標準差 σ={stats2[-1]['std']:.2f}")
        else:
            self.std_text_min.set_text("")
        self._autoscale(self.ax_min, x2, y2_min, y2_max)

        stats3 = list(self.hour_history)
        x3 = list(range(1, len(stats3) + 1))
        y3_mean = [s["mean"] for s in stats3]
        y3_max = [s["max"] for s in stats3]
        y3_min = [s["min"] for s in stats3]
        self.line_hour.set_data(x3, y3_mean)
        if self.band_hour is not None:
            self.band_hour.remove()
            self.band_hour = None
        if x3:
            self.band_hour = self.ax_hour.fill_between(x3, y3_min, y3_max, color="#8ab53f", alpha=0.15)
            self.std_text_hour.set_text(f"最新標準差 σ={stats3[-1]['std']:.2f}")
        else:
            self.std_text_hour.set_text("")
        self._autoscale(self.ax_hour, x3, y3_min, y3_max)

        self.canvas.draw_idle()

    @staticmethod
    def _autoscale(ax, x, y_low, y_high):
        if not x:
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            return
        ax.set_xlim(1, max(x[-1], 2))
        ymin, ymax = min(y_low), max(y_high)
        if ymin == ymax:
            ymin -= 1
            ymax += 1
        pad = (ymax - ymin) * 0.15 or 1
        ax.set_ylim(ymin - pad, ymax + pad)

    def _update_heatmap(self):
        sums = np.zeros((24, 6))
        counts = np.zeros((24, 6))
        for s in self.today_minute_stats:
            ts = s["timestamp"]
            hour = int(ts[8:10])
            minute = int(ts[10:12])
            block = minute // 10
            sums[hour, block] += s["mean"]
            counts[hour, block] += 1

        grid = np.full((24, 6), np.nan)
        mask = counts > 0
        grid[mask] = sums[mask] / counts[mask]

        self.heatmap_im.set_data(grid)
        valid = grid[~np.isnan(grid)]
        if valid.size > 0:
            self.heatmap_im.set_clim(vmin=float(valid.min()), vmax=float(valid.max()))
        self.canvas.draw_idle()

    def poll(self):
        if self.client is None:
            self.root.after(POLL_INTERVAL_MS, self.poll)
            return

        if not self.client.connected:
            self.value_label.config(text="--")
            self.status_label.config(text="連線中斷，嘗試重新連線...", fg="orange")
            try:
                self.client.close()
            except Exception:
                pass
            try:
                if self.client.connect():
                    self.status_label.config(text="重新連線成功", fg="green")
            except Exception as e:
                self.status_label.config(text=f"重新連線失敗: {e}", fg="red")
        else:
            try:
                rr = self.client.read_holding_registers(
                    address=PV_REGISTER, count=1, device_id=SLAVE_ID
                )
                if rr.isError():
                    self.status_label.config(text=f"讀取錯誤: {rr}", fg="red")
                else:
                    raw = rr.registers[0]
                    if raw >= 0x8000:
                        raw -= 0x10000
                    temp = raw / (10 ** DECIMALS)
                    self.value_label.config(text=f"{temp:.0f}")
                    self.status_label.config(text="連線正常", fg="green")

                    self._record_temperature(temp)

                    if temp > TEMP_HIGH_THRESHOLD and not self.alert_active:
                        self.alert_active = True
                        alert_text = (f"目前溫度: {temp:.1f}°C\n"
                                       f"已超過設定上限: {TEMP_HIGH_THRESHOLD}°C")
                        if ENABLE_TELEGRAM:
                            send_telegram_message(f"⚠️ 溫度警報\n{alert_text}")
                        if ENABLE_EMAIL:
                            send_email_alert("【溫度警報】Azbil C15溫控器超溫", alert_text)
                    elif temp <= TEMP_HIGH_THRESHOLD - ALERT_HYSTERESIS:
                        self.alert_active = False

                    if self.mqtt_client is not None:
                        now = time.time()
                        if now - self.last_publish_time >= MQTT_PUBLISH_INTERVAL_SEC:
                            self.last_publish_time = now
                            payload = {
                                "device": "azbil_c15tv0ta030a",
                                "temperature_c": temp,
                                "timestamp": int(now),
                            }
                            try:
                                self.mqtt_client.publish(
                                    MQTT_TOPIC, json.dumps(payload), qos=1, retain=True
                                )
                            except Exception:
                                pass
            except Exception as e:
                self.status_label.config(text=f"通訊中斷，準備重新連線: {e}", fg="red")
                try:
                    self.client.close()
                except Exception:
                    pass

        self.root.after(POLL_INTERVAL_MS, self.poll)

    def on_close(self):
        try:
            self.client.close()
        except Exception:
            pass
        if self.mqtt_client is not None:
            try:
                self.mqtt_client.loop_stop()
                self.mqtt_client.disconnect()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = TempMonitorApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
