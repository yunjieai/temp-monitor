#include <Arduino.h>
#include "Arduino_LED_Matrix.h"

ArduinoLEDMatrix matrix;

// ── 可調參數 ──────────────────────────────────
const int   LED_COUNT  = 12;   // 最上排燈的數量 (0–11)
const int   DELAY_MS   = 80;   // 每格移動速度 (毫秒)
// ─────────────────────────────────────────────

void setup() {
  matrix.begin();
  matrix.clear();   // 一行清空，取代原本的 96 次迴圈
}

// 讓單顆燈從 start 移動到 end（支援正反向）
void scanRow(int start, int end) {
  int step = (end > start) ? 1 : -1;
  for (int i = start; i != end + step; i += step) {
    matrix.on(i);
    delay(DELAY_MS);
    matrix.off(i);
  }
}

void loop() {
  scanRow(0,  11);  // 正向：左 → 右
  scanRow(10,  1);  // 反向：右 → 左（頭尾不重複停頓）
}
