#include <Arduino.h>
#include "Arduino_LED_Matrix.h" // 引入 Uno R4 WiFi 專用點矩陣函式庫

ArduinoLEDMatrix matrix; // 建立點矩陣物件

void setup() {
  matrix.begin(); // 啟動點矩陣
  
  // 先把整個矩陣清空，確保出廠的愛心不留殘影
  for (int i = 0; i < 96; i++) {
    matrix.off(i);
  }
}

void loop() {
  // 1. 正向：由左到右 (最上排燈號編號 0 到 11)
  for (int i = 0; i < 12; i++) {
    matrix.on(i);   // 點亮第 i 顆燈
    delay(80);      // 移動速度 (毫秒)
    matrix.off(i);  // 熄滅第 i 顆燈，準備亮下一顆
  }

  // 2. 反向：由右到左 (從編號 10 反向亮回編號 1，避免兩端重複停頓)
  for (int i = 10; i > 0; i--) {
    matrix.on(i);   // 點亮第 i 顆燈
    delay(80);      // 移動速度 (毫秒)
    matrix.off(i);  // 熄滅第 i 顆燈
  }
}
