#include <Arduino.h>

#define VREF 4.26

void setup()
{
  Serial.begin(115200);
}

void loop()
{
  int adc = analogRead(A0);

  float voltage = adc * VREF / 1023.0;
  float temperature = voltage * 100.0;

  Serial.print("ADC=");
  Serial.print(adc);

  Serial.print(" Voltage=");
  Serial.print(voltage,3);

  Serial.print("V Temperature=");
  Serial.print(temperature,1);

  Serial.println(" C");

  delay(1000);
}