/*
  uno_r4_firmware.ino  (ModbusMaster 版本)
  --------------------
  Arduino UNO R4 WiFi 作為獨立的溫度監控閘道器：
    TTL↔RS485 模組 --Modbus RTU--> Azbil C15TV0TA030A
    UNO R4 WiFi 內建 WiFi --MQTT(TLS)--> HiveMQ Cloud

  【為什麼改用 ModbusMaster，而不是原本的 ArduinoModbus/ArduinoRS485？】
    官方的 ArduinoModbus / ArduinoRS485 函式庫目前尚未正式支援 UNO R4 WiFi
    使用的 renesas_uno 架構，編譯會直接失敗，是已知、目前官方尚未修復的
    相容性問題。改用 ModbusMaster 函式庫可以繞開這個問題：它只依賴標準的
    Stream 介面(這裡用 Serial1)，不牽涉任何 TCP 程式碼。缺點是：RS485
    模組的方向控制腳(DE/RE)需要自己寫程式碼控制，因此下面多了
    preTransmission() / postTransmission() 兩個函式。

  接線 (TTL-RS485 模組 <-> UNO R4 WiFi)：
    模組 VCC   -> 5V (或3.3V，依模組規格)
    模組 GND   -> GND
    模組 RXD   -> D1 (TX1, UNO R4 硬體 Serial1 的 TX)
    模組 TXD   -> D0 (RX1, UNO R4 硬體 Serial1 的 RX)
    若模組有 DE / RE 方向控制腳位 (常見於 MAX485 模組)：
      DE + RE 短接在一起 -> 接到 D2 (由本程式控制方向)
    若模組是「自動方向偵測」型 (只有4pin: VCC/GND/RXD/TXD)：
      RS485_DE_PIN 設為 -1 即可（程式會自動略過方向控制腳的動作）

  接線 (RS-485 A/B <-> 溫控器)：
    模組 A(+) -> 溫控器 RS485 的 A(+) / SG(+)
    模組 B(-) -> 溫控器 RS485 的 B(-) / SG(-)
    請依 C15TV0TA030A 說明書設置編確認端子編號，且不可加終端電阻(J1需開路)。

  ⚠️ 重要提醒：
    若透過 USB-C 連接電腦看 Serial Monitor 除錯，同時又用 D0/D1(Serial1)
    做 RS485 通訊，部分使用者回報可能互相干擾。若遇到 Modbus 通訊怪異，
    可以先拔掉 USB-C 測試(改用電池/USB電源供電)，排除是否為此問題。

  需要安裝的 PlatformIO 函式庫 (寫在 platformio.ini 的 lib_deps)：
    - arduino-libraries/ArduinoMqttClient
    - arduino-libraries/Arduino_JSON
    - 4-20ma/ModbusMaster        <- 取代原本的 ArduinoRS485 + ArduinoModbus
    - WiFiS3                     (UNO R4 WiFi 內建，開發板套件自帶，會自動抓到)

  燒錄前務必修改下方「使用者設定」區塊。
*/

// ================== 函式庫引入 ==================
#include <WiFiS3.h>          // UNO R4 WiFi 專用的 WiFi 函式庫，負責連上無線網路
#include <WiFiSSLClient.h>   // 提供 TLS/SSL 加密連線功能，用來跟 MQTT Broker 做加密通訊
#include <ArduinoMqttClient.h> // MQTT 通訊協定客戶端，負責連線/發布/訂閱 MQTT 訊息
#include <ModbusMaster.h>    // 改用這個函式庫做 Modbus RTU 通訊，相容性較好，不依賴有問題的 ArduinoRS485
#include <Arduino_JSON.h>    // 用來組出 JSON 格式字串，方便把資料包成標準格式送出

// ================== 使用者設定 ==================
// --- WiFi 連線資訊 ---
const char* WIFI_SSID = "vivo 2006";     // 你的 WiFi 名稱(SSID)
const char* WIFI_PASSWORD = "0919120001";  // 你的 WiFi 密碼

// --- HiveMQ Cloud (MQTT over TLS) 連線資訊 ---
const char* MQTT_HOST = "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud"; // MQTT Broker 主機位址(HiveMQ Cloud 提供)
const int   MQTT_PORT = 8883;                  // MQTT over TLS 的標準連接埠(加密連線用 8883，非加密才是 1883)
const char* MQTT_USERNAME = "temp";            // 登入 MQTT Broker 用的帳號
const char* MQTT_PASSWORD = "temp0001";        // 登入 MQTT Broker 用的密碼
const char* MQTT_TOPIC = "azbil/c15/temperature"; // 發布溫度資料時要送去的「主題(topic)」路徑，訂閱端要訂閱同一個主題才收得到
const char* MQTT_CLIENT_ID = "uno-r4-wifi-gateway"; // 這台裝置在 MQTT Broker 上的識別名稱，同一個 Broker 下不可與其他裝置重複

// --- Modbus RTU (RS-485) 通訊設定 ---
const long MODBUS_BAUD = 9600;   // Modbus 通訊鮑率(傳輸速度)，必須跟溫控器面板上設定的數值完全一致，否則收不到正確資料
const int  RS485_DE_PIN = 2;     // RS485 模組的方向控制腳位(DE/RE 短接後接的那隻腳)，若模組是自動方向偵測型(無DE/RE)，這裡要設為 -1
const uint8_t SLAVE_ID = 1;      // Modbus 從站(溫控器)的通訊位址，需與溫控器本身設定的位址一致
const int PV_REGISTER = 9101;    // 要讀取的暫存器位址：依 Azbil 官方通訊資料清單，PV(目前量測值)位址 = 十進位9101 (即十六進位0x238D)
const int DECIMALS = 0;          // 小數點位數：實測確認此型號溫控器的 PV 原始讀值是整數，不含小數點，所以設為0

const unsigned long POLL_INTERVAL_MS = 1000; // 每隔多少毫秒讀取一次溫度並發布，改為1000毫秒(1秒)讀一次，配合網頁端24小時曲線圖需求
// 提醒：Modbus RTU 在9600鮑率下，單次讀取一個暫存器的來回時間大約只需要20~30毫秒，
// 遠低於1秒的間隔，所以改成每秒讀取一次，對這顆溫控器跟RS485匯流排來說負擔很小，不會有問題。
// ==================================================

// ================== 全域物件與變數 ==================
WiFiSSLClient wifiClient;          // 建立一個支援 TLS 加密的網路連線物件，之後給 MQTT 用來連線 Broker
MqttClient mqttClient(wifiClient); // 建立 MQTT 客戶端物件，底層透過上面的 wifiClient 做加密連線
ModbusMaster node;                 // 建立 ModbusMaster 物件，代表這台裝置扮演 Modbus 的「主站(master)」角色
unsigned long lastPoll = 0;        // 記錄「上一次讀取溫度」的時間點(millis())，用來計算是否已經到了下一次讀取的時間

// ================== RS485 方向控制函式 ==================
// 這兩個函式會在 ModbusMaster 每次要「送出」跟「接收」資料前後被自動呼叫，
// 用來手動切換 RS485 模組是處於「發送模式」還是「接收模式」

void preTransmission() {
  // 要開始送資料之前，先把 DE 腳拉高，讓 RS485 模組切到「發送模式」
  if (RS485_DE_PIN != -1) {
    digitalWrite(RS485_DE_PIN, HIGH);
    delayMicroseconds(50); // 給晶片一點點時間完成切換，避免第一個位元被吃掉(部分模組切換不是瞬間完成)
  }
}

void postTransmission() {
  // 資料送完之後，把 DE 腳拉低，讓 RS485 模組切回「接收模式」，才能聽到溫控器的回應
  if (RS485_DE_PIN != -1) {
    delayMicroseconds(50); // 送完最後一個位元後，稍微延遲一下再切換，避免最後一個位元被截斷(某些模組硬體反應較慢)
    digitalWrite(RS485_DE_PIN, LOW);
  }
}

// ================== WiFi 連線函式 ==================
void connectWiFi() {
  Serial.print("連線 WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD); // 開始嘗試連線指定的 WiFi 熱點
  while (WiFi.status() != WL_CONNECTED) { // 持續檢查連線狀態，還沒連上就一直等待
    delay(500);       // 每0.5秒檢查一次，避免無意義地瘋狂查詢
    Serial.print(".");// 印出點點點，讓使用者知道程式還在嘗試連線(不是當機)
  }
  // 連線成功後，印出目前板子分配到的區網 IP 位址，方便除錯確認
  Serial.println("\nWiFi 已連線，IP: " + WiFi.localIP().toString());
}

// ================== MQTT 連線函式 ==================
void connectMqtt() {
  mqttClient.setId(MQTT_CLIENT_ID); // 設定這台裝置在 MQTT Broker 上的識別 ID
  mqttClient.setUsernamePassword(MQTT_USERNAME, MQTT_PASSWORD); // 設定登入帳密(HiveMQ Cloud 需要帳密驗證)

  Serial.print("連線 MQTT Broker: ");
  Serial.println(MQTT_HOST);

  // 嘗試連線，若失敗會回傳 false，進入迴圈持續重試
  while (!mqttClient.connect(MQTT_HOST, MQTT_PORT)) {
    Serial.print("MQTT 連線失敗, 錯誤碼 = ");
    Serial.println(mqttClient.connectError()); // 印出錯誤代碼，方便查閱函式庫文件排查問題(例如帳密錯誤、憑證問題等)
    delay(2000); // 等待2秒後再重試，避免短時間內狂送連線請求
  }
  Serial.println("MQTT 已連線");
}

// ================== 初始化設定(開機時執行一次) ==================
void setup() {
  Serial.begin(115200);              // 開啟序列埠監控，鮑率設定為115200，方便透過 Serial Monitor 看除錯訊息
  while (!Serial && millis() < 3000) {} // 等待序列埠準備好，最多等3秒(避免板子卡在這裡等不到就一直卡住)

  connectWiFi();  // 先確保 WiFi 連上
  connectMqtt();  // 再確保 MQTT 連上

  // 初始化 RS485 方向控制腳位(若模組是自動方向偵測型，RS485_DE_PIN = -1，就不需要設定這隻腳)
  if (RS485_DE_PIN != -1) {
    pinMode(RS485_DE_PIN, OUTPUT);
    digitalWrite(RS485_DE_PIN, LOW); // 開機預設先切到「接收模式」，避免一開機就佔用匯流排
  }

  // 初始化 Serial1(UNO R4 的硬體序列埠，接 RS485 模組的那組 D0/D1)
  // SERIAL_8O1 代表：8個資料位元(Data bits) + O=Odd奇同位元檢查(Parity) + 1個停止位元(Stop bit)
  // 此設定已依實際測試結果(對應官方文件C68=1)修正確認過，務必與溫控器實際設定一致，否則會通訊失敗或收到亂碼
  Serial1.begin(MODBUS_BAUD, SERIAL_8O1);

  // 初始化 ModbusMaster：指定要通訊的從站位址，以及底層要用哪個 Serial 介面(這裡用 Serial1)
  node.begin(SLAVE_ID, Serial1);

  // 註冊方向控制的回呼函式，讓 ModbusMaster 每次收發資料時自動呼叫，幫我們切換 RS485 方向
  node.preTransmission(preTransmission);
  node.postTransmission(postTransmission);
}

// ================== 讀取溫度函式 ==================
// 透過 Modbus RTU 向溫控器要一筆溫度資料，讀取成功回傳 true，並把結果寫入傳入的 outTemp 參數(用參照傳遞)
bool readTemperature(float &outTemp) {
  // 向「保持暫存器(Holding Registers)」，從 PV_REGISTER 這個位址開始，讀取1個暫存器
  uint8_t result = node.readHoldingRegisters(PV_REGISTER, 1);

  if (result != node.ku8MBSuccess) {
    // result 不是成功代碼，代表讀取失敗，印出錯誤碼方便查閱函式庫文件對照(例如逾時、CRC錯誤、從站無回應等)
    Serial.print("Modbus 讀取失敗, 錯誤碼 = 0x");
    Serial.println(result, HEX);
    return false; // 讀取失敗，回傳 false，呼叫端就不會拿這次的資料去發布
  }

  // 讀到的原始資料是16位元，這裡轉型成有號整數(int16_t)，
  // 這樣才能正確處理「負溫度」的情況(若用無號整數，負數會被誤判成一個很大的正數)
  int16_t raw = (int16_t)node.getResponseBuffer(0);

  // 依照 DECIMALS 設定的小數位數，把原始整數值換算成實際的攝氏溫度
  // 例如：若 DECIMALS=1，代表原始值要除以10才是實際溫度(例如原始值253 → 25.3°C)
  // 此專案 DECIMALS=0，代表原始值本身就是整數溫度，不需要額外換算
  outTemp = raw / (float)pow(10, DECIMALS);
  return true; // 讀取成功
}

// ================== 發布溫度到 MQTT 函式 ==================
void publishTemperature(float temp) {
  JSONVar payload; // 建立一個 JSON 物件，用來組裝要送出的資料內容
  payload["device"] = "azbil_c15tv0ta030a";       // 標示資料來源裝置型號，方便訂閱端分辨資料是哪台儀器送來的
  payload["temperature_c"] = temp;                 // 這次讀到的攝氏溫度數值
  payload["timestamp"] = (long)(millis() / 1000);  // 時間戳記：用開機後經過的秒數表示(注意：這不是真實世界時間，只是相對開機時間)

  String json = JSON.stringify(payload); // 把 JSON 物件轉換成字串格式，才能透過 MQTT 傳送出去

  // 開始一則 MQTT 訊息：
  //   第2個參數 json.length()：訊息的位元組長度
  //   第3個參數 true：retain旗標，代表 Broker 會保留這則訊息，新訂閱者一連上就能立刻拿到「最後一次」的溫度值
  //   第4個參數 1：QoS等級1，代表訊息至少會送達一次(可能重複，但不會遺失)
  mqttClient.beginMessage(MQTT_TOPIC, json.length(), true /*retain*/, 1 /*qos*/);
  mqttClient.print(json);   // 寫入實際的 JSON 內容
  mqttClient.endMessage();  // 結束並真正送出這則訊息

  Serial.println("已發布: " + json); // 在序列埠印出這次送出的內容，方便對照雲端是否有正確收到
}

// ================== 主迴圈(開機後不斷重複執行) ==================
void loop() {
  // 隨時檢查 WiFi 是否斷線，若斷線就自動重新連線，確保裝置長時間運作的穩定性(避免路由器重開機等意外導致永久斷線)
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }
  // 同樣地，檢查 MQTT 連線是否還在，斷線就自動重連
  if (!mqttClient.connected()) {
    connectMqtt();
  }
  mqttClient.poll(); // 讓 MQTT 客戶端處理背景事務(例如維持連線的心跳訊號)，這行必須經常呼叫，否則連線可能會被 Broker 判定逾時斷開

  // 計算距離上次讀取溫度是否已經過了設定的間隔時間(POLL_INTERVAL_MS)
  if (millis() - lastPoll >= POLL_INTERVAL_MS) {
    lastPoll = millis(); // 更新「上次讀取時間」為現在，重新開始倒數下一次的間隔
    float temp;
    if (readTemperature(temp)) { // 讀取成功才繼續往下印出並發布，讀取失敗則這次迴圈就跳過，等下一次再試
      Serial.print("PV = ");
      Serial.print(temp, 2); // 印出溫度，保留小數點後2位方便閱讀
      Serial.println(" °C");
      publishTemperature(temp); // 把這次讀到的溫度發布到 MQTT
    }
  }
}
