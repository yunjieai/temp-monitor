"""
gui_monitor.py
----------------
簡易桌面GUI：每 POLL_INTERVAL_MS 讀取一次 Azbil C15TV0TA030A 的PV溫度值，
顯示在畫面上，並可選擇同時發布到 MQTT(HiveMQ Cloud)，讓手機/網頁能遠端監看。

安裝套件（若尚未安裝）：
  pip install pymodbus pyserial paho-mqtt

執行：
  python gui_monitor.py
"""

import time
import json
import ssl
import smtplib
from email.mime.text import MIMEText
import urllib.request
import urllib.parse
import tkinter as tk
from tkinter import ttk
import serial.tools.list_ports
from pymodbus.client import ModbusSerialClient
import paho.mqtt.client as mqtt

# 僅供Telegram的HTTPS請求使用truststore(Windows系統信任的憑證清單)，
# 刻意不呼叫truststore.inject_into_ssl()做全域替換，避免影響到MQTT(paho-mqtt)原本正常運作的TLS驗證機制。
try:
    import truststore
    _TELEGRAM_SSL_CONTEXT = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
except ImportError:
    print("提醒：尚未安裝 truststore，若Telegram發送出現SSL憑證錯誤，"
          "請執行: python -m pip install truststore")
    _TELEGRAM_SSL_CONTEXT = ssl.create_default_context()

# ====== Modbus設定（跟之前驗證過的設定保持一致） ======
# 注意：COM埠現在改由畫面上的下拉選單選擇（方便同一份程式在不同電腦上使用），
# 這裡的 DEFAULT_SERIAL_PORT 只是下拉選單的預設猜測值，找不到就會自動選第一個偵測到的COM埠。
DEFAULT_SERIAL_PORT = "COM8"
BAUDRATE = 9600
PARITY = "O"          # 依C68實測值＝奇同位
SLAVE_ID = 1
PV_REGISTER = 0x238D      # 官方通訊資料清單確認的PV位址（十進位9101 / 0x238D）
DECIMALS = 0              # 實測確認：PV原始值無小數點，DECIMALS=0(raw值除以10^0=1)
POLL_INTERVAL_MS = 2000   # 每2秒讀取一次
# ==========================================================================

# ====== MQTT設定：填入你的HiveMQ Cloud資訊，並把ENABLE_MQTT設為True才會啟用 ======
ENABLE_MQTT = True
MQTT_HOST = "6b871cd5e09b489dbf2f8cecd2557d42.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USERNAME = "temp"
MQTT_PASSWORD = "temp0001"
MQTT_TOPIC = "azbil/c15/temperature"
MQTT_CLIENT_ID = "gui-monitor-publisher"
MQTT_PUBLISH_INTERVAL_SEC = 2   # 為避免太頻繁發送，每隔幾秒才發布一次(畫面仍每0.5秒更新)
# ==========================================================================

# ====== Telegram推播設定（公司網路已封鎖telegram.org，先關閉避免持續報錯）======
ENABLE_TELEGRAM = False
TELEGRAM_BOT_TOKEN = "8339192759:AAE4vXsQZ3GcuzA_sRu3XiAuzfeMde6dQ24"
TELEGRAM_CHAT_ID = "8987703678"
# ==========================================================================

# ====== Email警報設定：超過上限溫度時透過公司Exchange信箱寄信通知 ======
ENABLE_EMAIL = True
SMTP_HOST = "smtp.office365.com"      # !! 請跟公司IT確認實際SMTP伺服器位址 !!
SMTP_PORT = 587                          # 587=STARTTLS加密(較常見)；若IT說用25且不加密則改成25
SMTP_USE_TLS = True                      # 若公司內網SMTP不需要加密，改成False
SMTP_REQUIRE_AUTH = True                 # 若公司內網SMTP不需要帳密驗證(常見於印表機/系統用途)，改成False
SMTP_USERNAME = "you@yourcompany.com"    # 寄件人信箱(登入帳號，通常跟寄件人相同)
SMTP_PASSWORD = "your_email_password"    # 信箱密碼(若公司用Microsoft 365且開啟雙重驗證，需改用「應用程式密碼」)
EMAIL_FROM = "you@yourcompany.com"       # 寄件人
EMAIL_TO = "you@yourcompany.com"         # 收件人(通常填自己的信箱，手機Email App會跳通知)

TEMP_HIGH_THRESHOLD = 30.0    # 超過這個溫度(°C)才發送警報
ALERT_HYSTERESIS = 1.0          # 溫度要降回「門檻-1.0°C」以下才會重置警報狀態，避免在門檻附近來回通知(防手震)
# ==========================================================================


def send_telegram_message(text: str) -> bool:
    """透過Telegram Bot API發送一則文字訊息，成功回傳True，失敗回傳False（不會拋出例外中斷主程式）"""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": TELEGRAM_CHAT_ID, "text": text}).encode("utf-8")
    try:
        handler = urllib.request.HTTPSHandler(context=_TELEGRAM_SSL_CONTEXT)
        opener = urllib.request.build_opener(handler)
        req = urllib.request.Request(url, data=data)
        with opener.open(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"Telegram發送失敗: {e}")
        return False


def send_email_alert(subject: str, body: str) -> bool:
    """透過公司Exchange SMTP寄出警報信件，成功回傳True，失敗回傳False（不會拋出例外中斷主程式）"""
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = EMAIL_TO

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as server:
            if SMTP_USE_TLS:
                server.starttls()
            if SMTP_REQUIRE_AUTH:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, [EMAIL_TO], msg.as_string())
        return True
    except Exception as e:
        print(f"Email發送失敗: {e}")
        return False


class TempMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("溫度監控系統")
        self.root.geometry("500x320")
        self.root.configure(bg="white")
        self.root.resizable(False, False)

        # 外框（模擬圖片中的大黑框）
        outer = tk.Frame(root, bg="white", highlightbackground="black",
                          highlightthickness=3)
        outer.place(x=10, y=10, width=480, height=300)

        # 標題
        title = tk.Label(outer, text="溫度監控系統", font=("Microsoft JhengHei", 22, "bold"),
                          bg="white", fg="black")
        title.place(x=140, y=20)

        # 環境溫度 標籤
        label = tk.Label(outer, text="環境溫度:", font=("Microsoft JhengHei", 16),
                          bg="white", fg="black")
        label.place(x=30, y=100)

        # 數值框
        value_box = tk.Frame(outer, bg="white", highlightbackground="black",
                              highlightthickness=2)
        value_box.place(x=150, y=90, width=140, height=45)

        self.value_label = tk.Label(value_box, text="--", font=("Consolas", 20, "bold"),
                                     bg="white", fg="black")
        self.value_label.place(relx=0.5, rely=0.5, anchor="center")

        # 單位
        unit_label = tk.Label(outer, text="度", font=("Microsoft JhengHei", 16),
                               bg="white", fg="black")
        unit_label.place(x=305, y=100)

        # ====== COM埠選擇區塊（方便同一份程式/exe在不同電腦上使用） ======
        port_label = tk.Label(outer, text="COM埠:", font=("Microsoft JhengHei", 11),
                               bg="white", fg="black")
        port_label.place(x=30, y=150)

        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(outer, textvariable=self.port_var, width=10,
                                        state="readonly", font=("Consolas", 10))
        self.port_combo.place(x=95, y=150)

        refresh_btn = tk.Button(outer, text="重新整理", command=self.refresh_ports,
                                 font=("Microsoft JhengHei", 9))
        refresh_btn.place(x=210, y=147)

        self.connect_btn = tk.Button(outer, text="連線", command=self.on_connect_clicked,
                                      font=("Microsoft JhengHei", 9, "bold"), bg="#e8f5e9")
        self.connect_btn.place(x=290, y=147)
        # ==========================================================================

        # 連線狀態（小字，方便除錯，不影響原本版面配置）
        self.status_label = tk.Label(outer, text="請選擇COM埠並按下連線", font=("Microsoft JhengHei", 9),
                                      bg="white", fg="gray")
        self.status_label.place(x=30, y=190)

        # MQTT獨立狀態顯示（避免跟上面的Modbus狀態互相覆蓋）
        self.mqtt_status_label = tk.Label(outer, text="", font=("Microsoft JhengHei", 9),
                                           bg="white", fg="gray")
        self.mqtt_status_label.place(x=30, y=210)

        # 初始化COM埠下拉選單內容
        self.refresh_ports()

        # Modbus client 改為使用者按下「連線」按鈕後才建立，初始為None
        self.client = None

        # 建立 MQTT 連線（若ENABLE_MQTT=False則完全不啟用，不影響原本純本地顯示功能）
        self.mqtt_client = None
        self.mqtt_connected = False
        self.last_publish_time = 0
        self.alert_active = False  # 追蹤是否已經在本次超溫期間發送過警報，避免重複轟炸
        if ENABLE_MQTT:
            self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=MQTT_CLIENT_ID)
            self.mqtt_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
            self.mqtt_client.tls_set()

            def on_mqtt_connect(client, userdata, flags, reason_code, properties):
                if reason_code == 0:
                    self.mqtt_connected = True
                    self.mqtt_status_label.config(text="MQTT: 已連線", fg="green")
                else:
                    self.mqtt_connected = False
                    # reason_code非0代表被broker拒絕，例如帳密錯誤(Not authorized)
                    self.mqtt_status_label.config(
                        text=f"MQTT連線被拒絕(reason_code={reason_code})，請檢查HiveMQ帳密", fg="red"
                    )

            def on_mqtt_disconnect(client, userdata, flags, reason_code, properties):
                self.mqtt_connected = False
                self.mqtt_status_label.config(text="MQTT: 連線中斷", fg="orange")

            self.mqtt_client.on_connect = on_mqtt_connect
            self.mqtt_client.on_disconnect = on_mqtt_disconnect
            self.mqtt_client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            self.mqtt_client.loop_start()

        self.poll()

    def refresh_ports(self):
        """掃描目前電腦上可用的COM埠，更新下拉選單內容"""
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_combo["values"] = ports
        if not ports:
            self.port_var.set("")
            self.status_label.config(text="找不到任何COM埠，請確認USB-RS485轉換器已插上", fg="red")
            return
        # 優先選擇跟預設值相符的COM埠；找不到就選第一個偵測到的
        if DEFAULT_SERIAL_PORT in ports:
            self.port_var.set(DEFAULT_SERIAL_PORT)
        else:
            self.port_var.set(ports[0])

    def on_connect_clicked(self):
        """使用者按下「連線」按鈕：關閉舊連線(若有)，用下拉選單選擇的COM埠重新建立連線"""
        selected_port = self.port_var.get()
        if not selected_port:
            self.status_label.config(text="請先選擇一個COM埠", fg="red")
            return

        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass

        self.status_label.config(text=f"正在連線 {selected_port} ...", fg="gray")
        self.client = ModbusSerialClient(
            port=selected_port, baudrate=BAUDRATE, parity=PARITY,
            stopbits=1, bytesize=8, timeout=1,
        )
        if self.client.connect():
            self.status_label.config(text=f"{selected_port} 連線成功", fg="green")
        else:
            self.status_label.config(text=f"{selected_port} 連線失敗，請確認COM埠是否正確", fg="red")

    def poll(self):
        # 尚未按下連線按鈕(或連線物件還沒建立)時，先跳過Modbus讀取，僅維持輪詢排程
        if self.client is None:
            self.root.after(POLL_INTERVAL_MS, self.poll)
            return

        # 每次輪詢都先檢查目前是否為連線狀態；pymodbus的 client.connected
        # 會在實體斷線(拔線)後自動變成 False，因此這裡可以用它來判斷是否需要重連。
        if not self.client.connected:
            self.value_label.config(text="--")
            self.status_label.config(text="連線中斷，嘗試重新連線...", fg="orange")
            try:
                # 拔插線後COM埠有時需要先明確關閉再重新開啟才抓得到
                self.client.close()
            except Exception:
                pass
            try:
                if self.client.connect():
                    self.status_label.config(text="重新連線成功", fg="green")
            except Exception as e:
                self.status_label.config(text=f"重新連線失敗: {e}", fg="red")
        else:
            try:
                rr = self.client.read_holding_registers(
                    address=PV_REGISTER, count=1, device_id=SLAVE_ID
                )
                if rr.isError():
                    self.status_label.config(text=f"讀取錯誤: {rr}", fg="red")
                else:
                    raw = rr.registers[0]
                    if raw >= 0x8000:  # 負溫度的16bit補數轉換
                        raw -= 0x10000
                    temp = raw / (10 ** DECIMALS)
                    self.value_label.config(text=f"{temp:.0f}")
                    self.status_label.config(text="連線正常", fg="green")

                    # 超溫警報：溫度超過門檻且尚未發送過警報時才通知一次，
                    # 直到溫度降回「門檻-ALERT_HYSTERESIS」以下才會重置，允許下次再超溫時重新通知
                    if temp > TEMP_HIGH_THRESHOLD and not self.alert_active:
                        self.alert_active = True
                        alert_text = (f"目前溫度: {temp:.1f}°C\n"
                                       f"已超過設定上限: {TEMP_HIGH_THRESHOLD}°C")
                        if ENABLE_TELEGRAM:
                            send_telegram_message(f"⚠️ 溫度警報\n{alert_text}")
                        if ENABLE_EMAIL:
                            send_email_alert("【溫度警報】Azbil C15溫控器超溫", alert_text)
                    elif temp <= TEMP_HIGH_THRESHOLD - ALERT_HYSTERESIS:
                        self.alert_active = False

                    # 發布到 MQTT（若啟用），依 MQTT_PUBLISH_INTERVAL_SEC 控制發送頻率
                    if self.mqtt_client is not None:
                        now = time.time()
                        if now - self.last_publish_time >= MQTT_PUBLISH_INTERVAL_SEC:
                            self.last_publish_time = now
                            payload = {
                                "device": "azbil_c15tv0ta030a",
                                "temperature_c": temp,
                                "timestamp": int(now),
                            }
                            try:
                                self.mqtt_client.publish(
                                    MQTT_TOPIC, json.dumps(payload), qos=1, retain=True
                                )
                            except Exception:
                                pass  # MQTT發布失敗不影響本地畫面顯示
            except Exception as e:
                # 讀取過程中若拔線，會在這裡拋例外；關閉連線讓下一輪poll()進入重連流程
                self.status_label.config(text=f"通訊中斷，準備重新連線: {e}", fg="red")
                try:
                    self.client.close()
                except Exception:
                    pass

        # 每 POLL_INTERVAL_MS 毫秒再呼叫自己一次，形成持續輪詢（含自動重連）
        self.root.after(POLL_INTERVAL_MS, self.poll)

    def on_close(self):
        try:
            self.client.close()
        except Exception:
            pass
        if self.mqtt_client is not None:
            try:
                self.mqtt_client.loop_stop()
                self.mqtt_client.disconnect()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = TempMonitorApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
