#ifndef CONFIG_H
#define CONFIG_H

// ---------- 腳位定義 (依實際接線修改) ----------
#define X_PUL_PIN   2
#define X_DIR_PIN   3
#define Z_PUL_PIN   4
#define Z_DIR_PIN   5
#define B_PUL_PIN   6
#define B_DIR_PIN   7

#define X_LIMIT_PIN 8
#define Z_LIMIT_PIN 9
#define B_LIMIT_PIN 10

#define SPINDLE_CTRL_PIN 11   // C2拋光頭自轉：BLDC控制器/VFD轉速命令腳位(依實際選型調整)

// ---------- 校正參數 (★ 每台機器都不同，務必實測校正) ----------
const float STEPS_PER_MM_X  = 400.0;   // 步進/驅動器脈波數 x 減速比 / 導程(mm)
const float STEPS_PER_MM_Z  = 400.0;   // Z軸為伺服，依伺服驅動器電子齒輪比設定值計算
const float STEPS_PER_DEG_B = 88.888;  // 步進/驅動器脈波數 x 減速比 / 360度

// ---------- 運動參數 ----------
const float MAX_SPEED_X  = 3000;  // pulse/sec
const float MAX_ACCEL_X  = 6000;
const float MAX_SPEED_Z  = 2000;
const float MAX_ACCEL_Z  = 4000;
const float MAX_SPEED_B  = 2000;
const float MAX_ACCEL_B  = 4000;

const unsigned long COMM_TIMEOUT_MS = 3000;

#endif
