#ifndef SERIAL_PROTOCOL_H
#define SERIAL_PROTOCOL_H

void protocolInit();
void protocolPoll();   // 在loop()中持續呼叫，處理序列埠指令與失效保護

#endif
