"""C2拋光頭自轉軸的高階操作介面"""
from serial_link import SerialLink


class SpindleController:
    def __init__(self, link: SerialLink):
        self.link = link

    def set_speed(self, percent: int):
        cmd = f"S {percent}"
        if not self.link.send_and_wait(cmd):
            raise RuntimeError(f"主軸轉速指令逾時或失敗: {cmd}")

    def stop(self):
        self.set_speed(0)
