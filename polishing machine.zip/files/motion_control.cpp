#include <Arduino.h>
#include <AccelStepper.h>
#include <MultiStepper.h>
#include "config.h"
#include "motion_control.h"

// X/B軸：步進馬達(或閉迴路步進)。Z軸：伺服，脈波+方向介面同樣適用AccelStepper::DRIVER模式
static AccelStepper stepperX(AccelStepper::DRIVER, X_PUL_PIN, X_DIR_PIN);
static AccelStepper stepperZ(AccelStepper::DRIVER, Z_PUL_PIN, Z_DIR_PIN);
static AccelStepper stepperB(AccelStepper::DRIVER, B_PUL_PIN, B_DIR_PIN);
static MultiStepper axes;

void motionInit() {
  pinMode(X_LIMIT_PIN, INPUT_PULLUP);
  pinMode(Z_LIMIT_PIN, INPUT_PULLUP);
  pinMode(B_LIMIT_PIN, INPUT_PULLUP);

  stepperX.setMaxSpeed(MAX_SPEED_X);
  stepperX.setAcceleration(MAX_ACCEL_X);
  stepperZ.setMaxSpeed(MAX_SPEED_Z);
  stepperZ.setAcceleration(MAX_ACCEL_Z);
  stepperB.setMaxSpeed(MAX_SPEED_B);
  stepperB.setAcceleration(MAX_ACCEL_B);

  axes.addStepper(stepperX);
  axes.addStepper(stepperZ);
  axes.addStepper(stepperB);
}

bool motionMoveTo(float xMm, float zMm, float bDeg) {
  long targetPositions[3];
  targetPositions[0] = round(xMm  * STEPS_PER_MM_X);
  targetPositions[1] = round(zMm  * STEPS_PER_MM_Z);
  targetPositions[2] = round(bDeg * STEPS_PER_DEG_B);

  axes.moveTo(targetPositions);
  while (axes.run()) {
    // 阻塞等待這一段三軸同步移動完成
  }
  return true;
}

bool motionHome() {
  stepperX.setMaxSpeed(200);
  stepperZ.setMaxSpeed(200);
  stepperB.setMaxSpeed(200);

  bool xHomed = false, zHomed = false, bHomed = false;
  stepperX.moveTo(-100000);
  stepperZ.moveTo(-100000);
  stepperB.moveTo(-100000);

  while (!(xHomed && zHomed && bHomed)) {
    if (!xHomed) {
      if (digitalRead(X_LIMIT_PIN) == LOW) { stepperX.stop(); stepperX.setCurrentPosition(0); xHomed = true; }
      else stepperX.run();
    }
    if (!zHomed) {
      if (digitalRead(Z_LIMIT_PIN) == LOW) { stepperZ.stop(); stepperZ.setCurrentPosition(0); zHomed = true; }
      else stepperZ.run();
    }
    if (!bHomed) {
      if (digitalRead(B_LIMIT_PIN) == LOW) { stepperB.stop(); stepperB.setCurrentPosition(0); bHomed = true; }
      else stepperB.run();
    }
  }

  stepperX.setMaxSpeed(MAX_SPEED_X);
  stepperZ.setMaxSpeed(MAX_SPEED_Z);
  stepperB.setMaxSpeed(MAX_SPEED_B);
  return true;
}
