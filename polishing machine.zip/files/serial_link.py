"""底層序列埠收送邏輯，跟UNO R4的所有通訊都經由這個類別"""
import time
import serial
from config import SERIAL_PORT, BAUD_RATE, RESPONSE_TIMEOUT_SEC


class SerialLink:
    def __init__(self, port: str = SERIAL_PORT, baud: int = BAUD_RATE):
        self.ser = serial.Serial(port, baud, timeout=RESPONSE_TIMEOUT_SEC)
        time.sleep(2.0)  # 等待UNO R4插上序列埠後重置完成
        self._wait_ready()

    def _wait_ready(self):
        start = time.time()
        while time.time() - start < 5:
            line = self.ser.readline().decode(errors="ignore").strip()
            if line == "READY":
                print("[UNO R4] 韌體就緒")
                return
        print("[警告] 未收到 READY 訊息，仍繼續嘗試通訊")

    def send_and_wait(self, cmd: str) -> bool:
        """送出指令並等待 OK/ERR 回應"""
        self.ser.write((cmd + "\n").encode())
        start = time.time()
        while time.time() - start < RESPONSE_TIMEOUT_SEC:
            line = self.ser.readline().decode(errors="ignore").strip()
            if line == "OK":
                return True
            if line.startswith("ERR"):
                print(f"[錯誤回報] {line}")
                return False
        return False

    def ping(self) -> bool:
        self.ser.write(b"PING\n")
        resp = self.ser.readline().decode(errors="ignore").strip()
        return resp == "PONG"

    def close(self):
        self.ser.close()
