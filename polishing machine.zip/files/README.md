# 拋光機控制程式 v2 — 模組化架構

## 為什麼要拆檔

原本全部塞一個檔案，在只有X/Z/B三軸都是同類型馬達時還能忍受；
但現在 X/B 是步進、Z 是伺服、C2(拋光頭自轉) 是BLDC/VFD，三種完全不同的
控制邏輯混在一起，程式會越來越難讀、也難單獨測試某一軸。拆開後：

- 每個模組職責單一，改C2轉速控制邏輯不會不小心動到X/B/Z的插補邏輯
- 之後C2確定用BLDC還是VFD，只需要改 `spindle_control.cpp` / `spindle_controller.py`
  這一組檔案，其他完全不用動
- 方便individually測試：可以先只測 `motion_control`，不用等C2驅動器到貨

## Arduino端結構

```
uno_r4_firmware/
├── uno_r4_firmware.ino   主檔，只有 setup()/loop()
├── config.h              腳位、校正參數、運動參數
├── motion_control.h/.cpp X/Z/B三軸同步插補、回原點 (AccelStepper + MultiStepper)
├── spindle_control.h/.cpp C2拋光頭自轉轉速控制 (目前PWM佔位，待選型後改寫)
└── serial_protocol.h/.cpp 指令解析、分派給對應模組、通訊逾時保護
```

用Arduino IDE開啟`uno_r4_firmware.ino`，其餘.h/.cpp檔案放在同一資料夾，
IDE會自動一起編譯連結，不需要額外設定。

## Python端結構

```
pc/
├── config.py              設定值(埠號、CSV路徑等)
├── serial_link.py         底層序列埠收送
├── axis_controller.py     X/Z/B高階操作介面(呼叫serial_link)
├── spindle_controller.py  C2轉速命令介面(呼叫serial_link)
├── profile_loader.py      CSV讀取
├── main.py                主流程，組裝以上模組
└── lens_profile_example.csv
```

執行方式不變：`python main.py`(在pc資料夾內執行，確保各模組互相import正確)

## 之後擴充建議

- 視覺辨識(拋光布磨損檢測)可以再開一個 `vision_inspector.py` 模組，
  `main.py` 匯入後在適當時機呼叫，不用跟軸控邏輯混在一起
- C2最終選型確定後，`spindle_control.cpp`裡的TODO替換成實際的
  BLDC控制器PWM邏輯，或改用Modbus函式庫呼叫VFD，
  `serial_protocol.cpp`跟`spindle_controller.py`的呼叫介面完全不用改
