"""讀取非球面CSV座標檔"""
import csv


def load_profile(csv_path: str):
    points = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            points.append(
                (float(row["X_mm"]), float(row["Z_mm"]), float(row["B_deg"]))
            )
    return points
