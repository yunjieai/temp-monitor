SERIAL_PORT = "COM5"          # ★ 依實際情況修改
BAUD_RATE = 115200
CSV_PATH = "lens_profile_example.csv"
RESPONSE_TIMEOUT_SEC = 10
