"""X/Z/B三軸的高階操作介面，內部透過SerialLink跟UNO R4溝通"""
from serial_link import SerialLink


class AxisController:
    def __init__(self, link: SerialLink):
        self.link = link

    def home(self):
        print("[動作] 執行回原點...")
        if not self.link.send_and_wait("HOME"):
            raise RuntimeError("回原點逾時或失敗，請檢查限位開關與接線")
        print("[完成] 回原點成功")

    def move_to(self, x_mm: float, z_mm: float, b_deg: float):
        cmd = f"G1 X{x_mm:.4f} Z{z_mm:.4f} B{b_deg:.4f}"
        if not self.link.send_and_wait(cmd):
            raise RuntimeError(f"移動指令逾時或失敗: {cmd}")
