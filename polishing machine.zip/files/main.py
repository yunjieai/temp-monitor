"""主流程：組裝各模組，執行一次完整的CSV拋光路徑"""
import time
from config import CSV_PATH
from serial_link import SerialLink
from axis_controller import AxisController
from spindle_controller import SpindleController
from profile_loader import load_profile


def run_polish_path(axis: AxisController, points):
    total = len(points)
    print(f"[開始] 共 {total} 個座標點")
    t0 = time.time()
    for i, (x, z, b) in enumerate(points, start=1):
        axis.move_to(x, z, b)
        print(f"  [{i}/{total}] -> X={x:.3f}mm Z={z:.3f}mm B={b:.3f}deg  完成")
    print(f"[結束] 耗時 {time.time() - t0:.1f} 秒")


def main():
    link = SerialLink()
    axis = AxisController(link)
    spindle = SpindleController(link)

    try:
        if not link.ping():
            print("[警告] PING 無回應，請確認連線狀態")

        # controller.home()  # 開機或換型號後建議先執行回原點

        spindle.set_speed(60)   # 範例：拋光頭轉速命令(依實際單位為% 或 rpm調整)
        points = load_profile(CSV_PATH)
        run_polish_path(axis, points)
        spindle.stop()

    finally:
        link.close()


if __name__ == "__main__":
    main()
