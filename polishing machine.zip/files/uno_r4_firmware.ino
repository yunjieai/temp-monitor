/*
  UNO R4 韌體主檔 - 只負責 setup()/loop()，實際邏輯都在各模組裡：
    config.h            腳位與校正參數
    motion_control.*     X/Z/B三軸同步插補移動、回原點
    spindle_control.*    C2拋光頭自轉轉速控制
    serial_protocol.*    指令解析、分派、通訊逾時保護
*/
#include "config.h"
#include "motion_control.h"
#include "spindle_control.h"
#include "serial_protocol.h"

void setup() {
  motionInit();
  spindleInit();
  protocolInit();
}

void loop() {
  protocolPoll();
}
