#ifndef SPINDLE_CONTROL_H
#define SPINDLE_CONTROL_H

void spindleInit();
void spindleSetSpeed(int percentOrRpm);
void spindleStop();

#endif
