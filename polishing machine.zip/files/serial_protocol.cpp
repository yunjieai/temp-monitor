#include <Arduino.h>
#include "config.h"
#include "serial_protocol.h"
#include "motion_control.h"
#include "spindle_control.h"

static unsigned long lastCommandTime = 0;
static bool commTimeoutTriggered = false;

void protocolInit() {
  Serial.begin(115200);
  Serial.setTimeout(50);
  lastCommandTime = millis();
  Serial.println("READY");
}

static void handleMoveCommand(const String &line) {
  int xi = line.indexOf('X');
  int zi = line.indexOf('Z');
  int bi = line.indexOf('B');
  if (xi == -1 || zi == -1 || bi == -1) {
    Serial.println("ERR missing_axis");
    return;
  }
  float xMm  = line.substring(xi + 1, zi).toFloat();
  float zMm  = line.substring(zi + 1, bi).toFloat();
  float bDeg = line.substring(bi + 1).toFloat();

  motionMoveTo(xMm, zMm, bDeg);
  Serial.println("OK");
}

static void handleSpindleCommand(const String &line) {
  // 指令格式 "S <0~100>"，例如 "S 60"
  int value = line.substring(2).toInt();
  spindleSetSpeed(value);
  Serial.println("OK");
}

void protocolPoll() {
  if (millis() - lastCommandTime > COMM_TIMEOUT_MS) {
    if (!commTimeoutTriggered) {
      commTimeoutTriggered = true;
      spindleStop();
      // TODO: 加入其他斷線失效保護動作(例如Z軸抬升脫離鏡片)
    }
  }

  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) return;

    lastCommandTime = millis();
    commTimeoutTriggered = false;

    if (line.startsWith("G1")) {
      handleMoveCommand(line);
    } else if (line.startsWith("S ")) {
      handleSpindleCommand(line);
    } else if (line == "HOME") {
      motionHome();
      Serial.println("OK");
    } else if (line == "PING") {
      Serial.println("PONG");
    } else {
      Serial.println("ERR unknown_command");
    }
  }
}
