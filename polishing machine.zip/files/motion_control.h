#ifndef MOTION_CONTROL_H
#define MOTION_CONTROL_H

void motionInit();
bool motionMoveTo(float xMm, float zMm, float bDeg);
bool motionHome();

#endif
