#include <Arduino.h>
#include "config.h"
#include "spindle_control.h"

// TODO: C2拋光頭自轉軸最終選型後(BLDC控制器 或 VFD+AC馬達)在此改寫實作。
// 目前先以PWM輸出佔位示範；若改用VFD/Modbus通訊介面，這裡改成對應通訊函式庫呼叫，
// 上層(serial_protocol.cpp)呼叫的函式介面不需要改變。

void spindleInit() {
  pinMode(SPINDLE_CTRL_PIN, OUTPUT);
}

void spindleSetSpeed(int percentOrRpm) {
  int pwmValue = constrain(map(percentOrRpm, 0, 100, 0, 255), 0, 255);
  analogWrite(SPINDLE_CTRL_PIN, pwmValue);
}

void spindleStop() {
  analogWrite(SPINDLE_CTRL_PIN, 0);
}
